## Round-44 changes (2026-09-04)

**No new permissions, no new network endpoints, no new data collection.**
Privacy-relevant items from this review-fix round:

- **Backup rule files deleted**: `res/xml/backup_rules.xml` and
  `res/xml/data_extraction_rules.xml` were removed. They have been
  unreferenced since `allowBackup="false"` (the documented v1.0.4 design
  decision) — the app still does not participate in Android backup/restore;
  deleting the dead files changes nothing about data flows.
- **`usesCleartextTraffic` removed from the manifest** (F15): redundant —
  `network_security_config.xml` already blocks cleartext traffic entirely
  (`cleartextTrafficPermitted="false"`), and the manifest attribute is
  ignored when a networkSecurityConfig is set. No behavior change.
- **`network_security_config.xml` gained a `debug-overrides` block**
  (debug builds only; release trust anchors unchanged).
- **Engine binary minimum-size check lowered 50 MB → 5 MB**
  (`StockfishNative.java`, A16): the ELF magic + size gate still rejects
  truncated/stub engine binaries; see the "Engine Binary Integrity" section
  below (updated).
- Manifest additions `supportsRtl` + `enableOnBackInvokedCallback` (F13) are
  pure UI/navigation flags — no data-flow impact. The permission table below
  remains accurate (8 declared permissions, re-verified against
  `AndroidManifest.xml`).

## Round-43 changes (2026-09-04)

**No privacy-relevant changes.** The 58 dead i18n keys marked in round-42
(42-8, D5=A) were removed from `game-logic.js` — they were unreferenced
translation strings (no code path, no data flow). `chess.html` was rebuilt
(md5-consistent double build). The rest of the round is documentation:
README.md restructure, NOTICE / NOTICE-DroidFish / BUILDING.md /
8×README.license synchronization, and two factual corrections in this file:

- The wake-lock note below now matches the code (round-42, 42-4): the
  `EngineService` partial wake lock is acquired **once** in `onCreate()`
  with a 30-minute timeout and is **not** re-acquired by `onStartCommand`
  (an earlier wording claimed longer sessions re-acquire it — they do not).
- The "Engine Binary Integrity" section below now matches the code: the
  runtime checks are the ELF magic check plus a minimum-size check
  (`StockfishNative.java`; the threshold was 50 MB at the time — round-44
  (A16) later lowered it to 5 MB, see the round-44 section above); there is
  no baked-in SHA-256 runtime check.
  The known-good engine SHA-256 is documented in BUILDING.md for manual
  verification.

No new permissions, no new network endpoints, no new data collection. The
permission table below was re-verified against `AndroidManifest.xml`
(8 declared permissions) and the CSP summaries re-verified against
`index.html.tpl` / `stats.html`.

## Round-42 changes (2026-08-10)

**No privacy-relevant changes.** FIDE 6.9 timeout-draw copy finalization
(42-1), flag-fall clock zeroing (42-2), castle-mark designated-file
preference (42-3), wake-lock comment correction (42-4), license-tag
unification (42-5), SECURITY_FIXES.md sync (42-6/42-7), dead-key marking
(42-8), stale-comment batch (42-9), `_stripFnBody` hardening (42-10),
debug `.debug` applicationId suffix (42-11). No new permissions, no new
network endpoints, no new data collection.

## Round-41 changes (2026-08-10)

**No privacy-relevant changes.** Robustness consolidation (41-1~41-10).
Worth noting for completeness: 41-3 adds a 1 MB size cap to settings
import (local file handling only; fails fast with the existing toast);
41-7 sanitizes intercepted UCI commands before logging (CR/LF escaping —
log-injection hygiene, consistent with the round-19 JsBridgeGateway fix).
No new permissions, no new network endpoints, no new data collection.

## Round-40 changes (2026-08-10)

**No privacy-relevant changes.** Bug-fix tier (40-1~40-6): restartEngine
self-interrupt fix, castling-rights row checks, FIDE 6.9 strict timeout
draw, PGN tag-strip regex hardening, `fenToState` strict input validation.
No new permissions, no new network endpoints, no new data collection.

## Round-39 changes (2026-07-20)

**No privacy-relevant changes.** This round is pure code-quality cleanup
(continued SonarCloud rule fixes) — no new permissions, no new network
endpoints, no new data collection, no changes to existing data flows.

Specifically:
- `ai-bridge.js`, `game-logic.js`, `ui.js`, `ui-interactions.js`,
  `ui-gameflow.js`, `tablebase.js`: 47× `e&&e.message?e.message:e` →
  `e?.message?e.message:e` (SonarCloud S6582 — optional chaining, exact
  semantic equivalent). Affects only in-process error logging format.
- `ui.js`, `stats.html`: `href.indexOf('http://') !== 0` →
  `!href.startsWith('http://')` (SonarCloud S7765 — clearer prefix check).
  Affects only in-process URL scheme detection for the external-browser
  open path.
- `ui.js`: removed 3 unused local variables (`rLast`, `prevEval`, `ad`)
  (SonarCloud S1481/S1854 — dead code removal). No behavior change.
- `chess.html` rebuild: pure bundle regeneration from chess.src/*.js.
- BUILDING.md / PRIVACY.md / README.md / NOTICE / 8 README.license /
  Manual (zh+en) / worklog.md: pure documentation.

The Lichess Tablebase API remains the only network endpoint (unchanged since
v1.0.4). All other features remain fully offline.

## Round-38 changes (2026-07-20)

**No privacy-relevant changes.** This round is pure code-quality cleanup
(continued SonarCloud rule fixes) — no new permissions, no new network
endpoints, no new data collection, no changes to existing data flows.

Specifically:
- `ui.js`, `worker-pool.js`, `pgn-standard.js`, `tablebase.js`,
  `ui-interactions.js`, `ai-bridge.js`: SonarCloud rule fixes (S6535, S7765,
  S7769, S6660, S5869, S6653). All affect only in-process regex character
  classes, existence checks, math operations, or DOM API modernization; no
  IPC, no network, no storage changes.
- `stats.html`: SonarCloud rule fixes (S6353, S7765, S7780). Affects only
  in-process regex matching, existence checks, and string literal style.
- `chess.html` rebuild: pure bundle regeneration from chess.src/*.js.
- BUILDING.md / PRIVACY.md / README.md / NOTICE / 8 README.license /
  Manual (zh+en) / worklog.md: pure documentation.

All changes are confined to:
- `src/main/assets/chess.src/{ui,worker-pool,pgn-standard,tablebase,ui-interactions,ai-bridge}.js`
- `src/main/assets/chess.html` (rebuilt)
- `src/main/assets/stats.html`
- `BUILDING.md`, `README.md`, `NOTICE`, `PRIVACY.md`,
  `src/main/assets/chess.src/README.license`,
  `src/main/java/com/Regalia/README.license`,
  `src/main/assets/README.license`, `src/main/README.license`,
  `src/main/res/README.license`, `src/main/cpp/README.license`,
  `Manual/README.license`, `assets/README.license`,
  `worklog.md`, `Manual/Regalia-v1.2.3-manual-{zh,en}.html`

The Lichess Tablebase API remains the only network endpoint (unchanged since
v1.0.4). All other features remain fully offline.

## Round-37 changes (2026-07-20)

**No privacy-relevant changes.** This round is pure code-quality cleanup
(SonarCloud rule fixes) — no new permissions, no new network endpoints,
no new data collection, no changes to existing data flows.

Specifically:
- `ai-bridge.js`, `game-logic.js`, `state-store.js`, `ui.js`,
  `worker-pool.js`: SonarCloud rule fixes (S6645, S6644, S7718, S7786,
  S6653, S7719, S6661, S7760, S7762). All affect only in-process display
  label selection, error-type specificity, or DOM API modernization; no
  IPC, no network, no storage changes.
- `stats.html`: SonarCloud rule fixes (S7762, S7773). Affects only
  in-process DOM manipulation and parseFloat lexical scope.
- `engine_jni.cpp`: C++ modernization (cpp:S4962 nullptr, cpp:S1172
  unused parameter comment). Affects only JNI bridge compilation; no
  behavior change.
- `chess.html` rebuild: pure bundle regeneration from chess.src/*.js.
- BUILDING.md / PRIVACY.md / README.md / NOTICE / 8 README.license /
  Manual (zh+en) / worklog.md: pure documentation.

All changes are confined to:
- `src/main/assets/chess.src/{ai-bridge,game-logic,state-store,ui,worker-pool}.js`
- `src/main/assets/chess.html` (rebuilt)
- `src/main/assets/stats.html`
- `src/main/cpp/engine_jni.cpp`
- `BUILDING.md`, `README.md`, `NOTICE`, `PRIVACY.md`,
  `src/main/assets/chess.src/README.license`,
  `src/main/java/com/Regalia/README.license`,
  `src/main/assets/README.license`, `src/main/README.license`,
  `src/main/res/README.license`, `src/main/cpp/README.license`,
  `Manual/README.license`, `assets/README.license`,
  `worklog.md`, `Manual/Regalia-v1.2.3-manual-{zh,en}.html`

The Lichess Tablebase API remains the only network endpoint (unchanged since
v1.0.4). All other features remain fully offline.

## Round-36 changes (2026-07-20)

**No privacy-relevant changes.** This round is pure code-deduplication +
robustness refactoring of chess.src/*.js modules — no new permissions, no
new network endpoints, no new data collection, no changes to existing
data flows.

Specifically:
- `_computeEpTarget` / `_applyKingMove` / `_kingPosAfterMove` extractions
  in `game-logic.js`: affect only in-process chess move legality/state
  computation; no data leaves the device. The extracted helpers are
  byte-for-byte equivalent to the previous inline code (verified by
  Node-vm smoke tests).
- `evalBucket` / `_POV_LABEL_KEYS_PLAYER` / `_POV_LABEL_KEYS_WHITE` in
  `game-logic.js`: centralize the eval-threshold ladder previously
  duplicated between `ui.js:posDesc` and `pgn-standard.js:_pgnWhitePerspectiveLabel`.
  Affects only in-process display label selection; no IPC, no network.
- `isChess960Active()` in `chess960.js`: canonical Chess960-detection
  predicate. Affects only in-process variant detection; no IPC, no
  network.
- `randomSPID()` delegation to `secureRandomInt(960)`: affects only
  in-process SP-ID selection; no IPC, no network. The 518 fail-safe
  for crypto-unavailable is preserved.
- `_engineStopHard()` in `ai-bridge.js`: canonical hard-stop helper.
  Affects only in-process engine lifecycle; no data leaves the device.
  The helper closes a real robustness gap (ui.js:5466 was missing the
  sendToEngine('stop') fallback for older builds) — this is a
  behavior-correctness fix, not a privacy change.
- Shredder-FEN detection dedup (3 sites now delegate to
  `_needsShredderFEN`): affects only in-process FEN/PGN generation;
  no IPC, no network. **BUG FIX**: the inline copies missed the
  v1.2.3 round-21 per-color gating fix, misclassifying some standard
  positions as Chess960. Centralizing fixes this — behavior-correctness,
  not privacy.
- `_pad2` in `pgn-standard.js`: trivial zero-pad helper. Affects only
  in-process time-formatting; no IPC, no network.
- chess.html rebuild: pure bundle regeneration from chess.src/*.js.
- BUILDING.md / PRIVACY.md / README.md / NOTICE / 8 README.license /
  Manual (zh+en) / worklog.md: pure documentation.

All changes are confined to:
- `src/main/assets/chess.src/{game-logic,chess960,ai-bridge,pgn-standard,ui,ui-gameflow,ui-interactions}.js`
- `src/main/assets/chess.html` (rebuilt from chess.src/*.js)
- `BUILDING.md`, `README.md`, `NOTICE`, `PRIVACY.md`,
  `src/main/assets/chess.src/README.license`,
  `src/main/java/com/Regalia/README.license`,
  `src/main/assets/README.license`, `src/main/README.license`,
  `src/main/res/README.license`, `src/main/cpp/README.license`,
  `Manual/README.license`, `assets/README.license`,
  `worklog.md`, `Manual/Regalia-v1.2.3-manual-{zh,en}.html`

The Lichess Tablebase API remains the only network endpoint (unchanged since
v1.0.4). All other features remain fully offline.

## Round-35 changes (2026-07-20)

**No privacy-relevant changes.** This round is pure code-quality fix
(SonarCloud BUG + 2 MINOR code smells) + doc sync — no new permissions,
no new network endpoints, no new data collection, no changes to existing
data flows.

Specifically:
- StockfishNative `_lifecycleGeneration` AtomicInteger conversion
  (SonarCloud java:S3078): affects only in-process engine lifecycle
  concurrency semantics; no data leaves the device. The fix changes the
  field type from `volatile int` to `AtomicInteger` to make the `++`
  operation atomic — behavior is byte-for-byte equivalent.
- game-logic.js optional-chaining conversion (SonarCloud javascript:S6582
  ×2 sites): affects only in-process chess logic; no IPC, no network, no
  storage. The fix changes `!s||!s.board` → `!s?.board` and
  `!p||p.color!==winnerColor` → `p?.color!==winnerColor` — semantics
  verified equivalent.
- BUILDING.md H1 title addition + round-35 build notes: pure documentation.
- README.md/NOTICE/worklog.md/Manual round-35 entries: pure documentation.

All changes are confined to:
- `src/main/java/com/Regalia/StockfishNative.java`
- `src/main/assets/chess.src/game-logic.js`
- `src/main/assets/chess.html` (rebuilt from chess.src/*.js)
- `BUILDING.md`, `README.md`, `NOTICE`, `PRIVACY.md`,
  `src/main/assets/chess.src/README.license`,
  `src/main/java/com/Regalia/README.license`,
  `src/main/assets/README.license`, `src/main/README.license`,
  `src/main/res/README.license`, `src/main/cpp/README.license`,
  `Manual/README.license`, `assets/README.license`,
  `worklog.md`, `Manual/Regalia-v1.2.3-manual-{zh,en}.html`

The Lichess Tablebase API remains the only network endpoint (unchanged since
v1.0.4). All other features remain fully offline.

## Round-34 changes (2026-07-20)

**No privacy-relevant changes.** This round is pure bug-fix (Gitar
Changes Requested regression + CodeRabbit Major race fix) + doc cleanup
— no new permissions, no new network endpoints, no new data collection.

Specifically:
- StockfishNative shutdown race closure: affects only in-process engine
  lifecycle; no data leaves the device.
- MainActivity null-engine fallback fix: affects only in-process engine
  initialization retry logic; no IPC, no network, no storage.
- README.md/NOTICE/README.license/worklog.md: pure documentation.

All changes are confined to:
- `src/main/java/com/Regalia/{StockfishNative,MainActivity}.java`
- `README.md`, `NOTICE`, `src/main/java/com/Regalia/README.license`, `worklog.md`

## Round-33 changes (2026-07-20)

**No privacy-relevant changes.** This round is pure bug-fix + doc cleanup —
no new permissions, no new network endpoints, no new data collection, no
changes to existing data flows.

Specifically:
- StockfishNative shutdown() race fix + engineGoTimed timestamp capture:
  affects only in-process engine lifecycle; no data leaves the device.
- ChessWebViewClient isFinishing/isDestroyed check: affects only how
  external URLs are dispatched to the system browser; the URL itself is the
  only datum transmitted (unchanged from prior rounds).
- MainActivity stockfishEngine==null fallback + _stabilizationLock in
  onResume/onPause: affects only in-process state recovery; no IPC, no
  network, no storage.
- HapticManager Application Context normalization + cache timestamp=0 fix:
  affects only in-process haptic gating; no data leaves the device.
- NOTICE canonical GPL list update + Manual UI architecture diagram: pure
  documentation.

All changes are confined to:
- `src/main/java/com/Regalia/{StockfishNative,ChessWebViewClient,MainActivity,HapticManager}.java`
- `NOTICE` (canonical GPL list section only)
- `Manual/Regalia-v1.2.3-manual-{zh,en}.html` (UI architecture diagram + changelog)

The Lichess Tablebase API remains the only network endpoint (unchanged since
v1.0.4). All other features remain fully offline.

## Round-32 changes (2026-07-20)

**No privacy-relevant changes.** This round is pure bug-fix propagation +
comment cleanup — no new permissions, no new network endpoints, no new data
collection, no changes to existing data flows.

Specifically:
- StockfishNative + EngineHealthMonitor + ChessWebViewClient: switched
  interval-measurement timestamps from `System.currentTimeMillis()` to
  `SystemClock.elapsedRealtime()` (monotonic). Affects only in-process
  engine-health monitoring; no data leaves the device.
- state-store.js: header comment clarification (no code change).
- eco-data.js: extracted `_buildEcoLookups()` helper (refactor, no behavior
  change).
- pgn-standard.js: corrected a stale comment (no code change).
- MainActivity + StatsActivity + PermissionHelper + FileIoHelper: stale
  "API 21" / "Android 5.0" comments → "API 23" / "Android 6.0" to match
  minSdk=23. Comments only.

All changes are confined to:
- `src/main/assets/chess.src/{state-store,eco-data,pgn-standard}.js`
- `src/main/java/com/Regalia/{StockfishNative,EngineHealthMonitor,ChessWebViewClient,MainActivity,StatsActivity,PermissionHelper,FileIoHelper}.java`
- rebuilt `chess.html` (deterministic build from the .js modules above)

The Lichess Tablebase API remains the only network endpoint (unchanged since
v1.0.4). All other features remain fully offline.

## Round-31 changes (2026-07-20)

**No privacy-relevant changes.** This round is pure code-quality + stability
hardening — no new permissions, no new network endpoints, no new data
collection, no changes to existing data flows.

Specifically:
- `_evalOrMate` (ai-bridge.js): corrected mate===0 to return fallback eval
  instead of a -90000 sentinel. Affects in-app eval display only; no data
  leaves the device.
- `state-store.js`: dispatch/reset now deep-clone once instead of twice
  (pure performance optimization; same data, same external behavior).
- `winnerLacksMatingMaterial` (game-logic.js): refactored into helpers to
  reduce cognitive complexity. Semantics byte-for-byte equivalent (14-test
  FIDE 6.9 suite passes).
- `_settingsImportGen` `|0` → `Math.trunc`: SonarCloud S8786 style fix,
  no behavioral change.
- HapticManager + StabilizationHelper: cache/throttle timestamps switched
  from `System.currentTimeMillis()` to `SystemClock.elapsedRealtime()`
  (monotonic). No new sensor access, no new data collected.
- MainActivity: `_isFallbackMode` flag + `_stabilizationLock` synchronization.
  Affects only in-process event routing; no IPC, no network, no storage.

All changes are confined to:
- `src/main/assets/chess.src/{ai-bridge,state-store,game-logic}.js`
- `src/main/java/com/Regalia/{HapticManager,StabilizationHelper,MainActivity}.java`
- rebuilt `chess.html` (deterministic build from the .js modules above)

The Lichess Tablebase API remains the only network endpoint (unchanged since
v1.0.4). All other features remain fully offline.

<!--
  Privacy Policy — Regalia
  Copyright (C) 2026 Regalia
  Licensed under GNU Affero General Public License v3 (AGPL v3)

  AI-GEN: AI assisted
  This document was AI-assisted and has been reviewed for AGPL v3 compliance.
-->
# Privacy Policy — Regalia

Regalia is a fully offline chess application. This policy applies to the Regalia Android application (current version: **v1.2.3**, versionCode 123).

## Data Collection

**Regalia collects no personal data.** The application:

- Does not collect, transmit, or store any personal information
- Does not require user registration or accounts
- Does not include advertising SDKs or analytics services
- Does not track user behavior or game history remotely

## Network Access

Regalia's core features work entirely offline. The only network-dependent features are:

- **Syzygy Endgame Tablebase**: Queries the public Lichess Tablebase API (`tablebase.lichess.ovh`) for positions with 7 or fewer pieces. This is optional and automatically disabled when offline. No personal data is sent in these queries — only chess position data (FEN strings). All network traffic is forced over TLS 1.2+ via `TlsSecurityHelper.java` and `network_security_config.xml` (cleartext traffic is blocked entirely).
- **External hyperlinks (v1.0.4 Rev27+)**: When the user taps a hyperlink in the About dialog (e.g. the GitHub source code link, AGPL v3 / GPL v3 license links) or anywhere else in the app, the URL is handed to the system default browser via `Intent.ACTION_VIEW`. Regalia itself does not make any HTTP request — the browser app handles the URL fetch. Only http(s) URLs are allowed; other schemes are silently rejected. No Regalia data is sent to the browser; the URL itself is the only datum transmitted.

All other features, including AI gameplay, review analysis, PGN import/export, and engine configuration, work without any network connection.

**Content Security Policy (verified round-43):** both WebView pages enforce a
CSP meta policy. The main page (`chess.html`) uses `default-src 'none'` with
`connect-src https://tablebase.lichess.ovh` — the tablebase API is the only
permitted network origin — plus `object-src 'none'`, `form-action 'none'` and
`base-uri 'self'`. The statistics page (`stats.html`) uses
`connect-src 'none'` — it cannot make any network request at all.

## Local Data

Game data (board positions, move records, engine settings, PGN cache entries, eval cache) is stored locally on the device using browser localStorage, Android SharedPreferences, and app-private files. The on-device storage locations are:

- `/data/data/com.Regalia/app_webview/Local Storage/` — WebView localStorage (may be wiped by aggressive OEM memory managers like Xiaomi HyperOS 3)
- `/data/data/com.Regalia/shared_prefs/RegaliaEngine.xml` — SharedPreferences (engine settings, language preference, persistent kv_* fallback store)
- `/data/data/com.Regalia/files/eval_cache.json` — Eval cache (per-move Stockfish evaluations for review mode, v1.0.4 Rev20+)
- `/data/data/com.Regalia/files/pgn_cache/<name>.pgn` — PGN cache entries (saved via 📚 PGN Cache Manager)
- `/data/data/com.Regalia/files/pgn_cache/<name>.tags.json` — Tag files for PGN cache entries (v1.0.4 Rev20+)

### v1.0.4 Rev28: Stats↔main PGN sync

The stats page (`StatsActivity`) and the main/review page (`MainActivity`) now synchronize PGN data bidirectionally:

- **Entering stats page**: `openStatsPage()` always rebuilds the PGN from the current `moveRecords` and passes it to the stats page via the Intent extra `statsPayload`. No PGN data leaves the device.
- **Returning from stats page**: If the user imported a PGN on the stats page and tapped "Yes" on the "🗃️ Import PGN to game?" dialog, the imported PGN text is stashed in a static volatile field `StatsActivity.importedPGNOnStats` (in-memory only, never written to disk) and read by `MainActivity.onResume()` (one-shot — cleared immediately after read). The PGN is then imported into the main game via `importPGN()`. If the user tapped "No" or "Cancel", no data crosses the activity boundary.

This data:

- Never leaves the device
- Can be cleared by uninstalling the app or clearing app data
- Is not shared with any third party
- The PGN cache entries contain only chess game records (PGN format) — no personal or device-identifying information. They are never uploaded.
- The eval cache (`eval_cache.json`) contains per-move Stockfish evaluation scores (centipawn values, mate distances, search depths, WDL probabilities) keyed by review step index. It contains no personal or position-identifying information beyond the chess evaluation data itself. (v1.0.7+: capped at 2000 entries via LRU eviction — the currently-viewed step is never evicted; eviction order is preserved across app restarts.)
- The tag files contain user-defined tag strings (e.g., "opening", "tactics") for organizing PGN cache entries. They contain no personal or device-identifying information.

### v1.2.3 round-30: First-principles per-file review + robustness/perf optimizations (pure code change)

The v1.2.3 round-30 change (2026.7.19) is a continuation of the per-file, per-line first-principles review (3 parallel review agents covering all 11 JS modules + 19 Java files + C++/build configs). 20 actionable findings identified; 18 implemented (2 deferred — `_escapeHTML` wrapper kept for backward compatibility, `JsBridgeGateway.isSafeFileName` `..` check kept as defense-in-depth). All changes are semantics-preserving or pure robustness/perf improvements; no behavior change for valid inputs. Fixes span: (1) FIDE 6.9 K+B+B same-color gap in `winnerLacksMatingMaterial`; (2) MediaStore SQL LIKE wildcard injection in `FileIoHelper.addMediaStoreResults`; (3) `StatsActivity.loadAssetAsBase64` missing path-traversal check; (4) `EngineConfigHelper.detectBigCoreCount` BogoMIPS overwriting CPU max MHz; (5) MainActivity `stabilizationHelper`/`stabilizationEnabled` declared `volatile`; (6) `MainActivity.scheduleInitRetry` shows fallback UI after retries exhausted; (7) `StockfishNative.engineGoDepth` clamps depth to `[1, 60]`; (8) `state-store._notifyListeners` deep-clones the state snapshot handed to listeners; (9) `_savePGNYes` / `_makeLoadingClickable` polling now bounded; (10) `onSettingsImported` safety-net setTimeouts use a generation token; (11) `_requestBatchEval` not-ready branch no longer spins; (12) `_updateCtrlInfoPanel` uses `getElementById` instead of O(cards) text-scan; (13) `HapticManager.isHapticEnabled` caches the system setting for 5s; (14) `PgnCacheManager.sanitizeName` uses pre-compiled Patterns; (15) `_tbCache` LRU refresh saves one Map lookup; (16) `_parsePGN` brace-comment loop pre-checks; (17) `showToast` tracks the inner removal timer; (18) dead state / duplicated logic / dead API removed. **No new permissions, no new network access, no new data collection.** This is a pure code-organization + bug-fix + robustness + performance round.

### v1.2.3 round-29: PR #52 SonarCloud + CodeRabbit review fixes (pure code change)

The v1.2.3 round-29 change (2026.7.19) processes the PR #52 review reports (`SonarCloud_PR52_Issues_Summary.docx` + `PR52_Unresolved_Issues_Optimization.docx`). Every claimed issue was verified against the actual source — 14 real defects fixed, 6 false positives identified and skipped (with rationale documented in `README.md` round-29 entry and `worklog.md`). Fixes span: (1) new `winnerLacksMatingMaterial` function for proper FIDE 6.9 timeout-draw (asymmetric case); (2) `_restoreClocks` no longer calls `initGameClocks()` (which was overwriting restored clock values — Undo/Redo clock restoration regression fix); (3) `README.md` removed public signing-key credentials from round-13 release notes; (4) 49 AGPL v3 → GPL v3 license-tag corrections across NOTICE + 5 README.license files for 4 DroidFish-derived files (tablebase.js, stats.html, worker-pool.js, JsBridgeGateway.java); (5) SonarCloud code-quality cleanups (S8786 PGN regex canonicalization at 5 sites, S6582 optional chaining at 6 sites, S3358 nested ternary at 2 sites, S3504 var→const at 4 sites, S1481 dead local removal, S6551 toString fallback, S7780/S7781 String.raw + replaceAll); (6) documentation sync (permission list, manual toolbar description, res/README.license xml/ summary, worklog PDF count). **No new permissions, no new network access, no new data collection.** This is a pure code-organization + bug-fix + documentation round.

### v1.2.3 round-28: Undo/Redo clock restoration audit + baseSec completeness (pure code change)

The v1.2.3 round-28 change (2026.7.19) audits the Undo/Redo clock restoration feature requested by the user. The feature was already implemented in round-23 (Q3 fix) via `_snapshotClocks`/`_restoreClocks` helpers — a full round-trip verification confirms it works correctly (Undo records remaining time, Redo restores it). The only code change is adding `baseSec` to the clock snapshot for completeness (was missing — only affected PGN `[TimeControl]` tag which reads `gameClocks.baseSec`, but the existing value was retained so no bug). Also performed a first-principles review of all clock-related code (`recordMoveEnd`, `_tickGameClock`, `_restoreClocks`, `_redoStack` push timing) — all confirmed correct. **No new permissions, no new network access, no new data collection.** This is a pure code-completeness + audit round.

### v1.2.3 round-27: First-principles review + manual mockup fix (pure code change)

The v1.2.3 round-27 change (2026.7.19) is a first-principles review continuation. Verified i18n completeness (all 480+ keys have both zh and en values — no gaps). Fixed a misleading comment in `_onGameClockExpired` about `isDeadPosition` semantics. Removed a redundant `timeout` draw branch in `_deriveGameResult` (unreachable — the fallback already handles it). Fixed the cache-manager mockup in both zh and en manuals: removed the 📥 (import) button elements that were removed from the actual UI in v1.0.4 Rev24 but never removed from the mockup; updated text descriptions from "three buttons" to "two buttons". Updated the README.md directory tree with current file sizes (ui.js 6,791 lines, HapticManager.java 471 lines). **No new permissions, no new network access, no new data collection.** This is a pure code-comment + redundancy + documentation-accuracy round.

### v1.2.3 round-26: PGN Termination/comment配套修复 for FIDE 6.9 timeout draw (pure code change)

The v1.2.3 round-26 change (2026.7.19) is a follow-up to round-25's FIDE 6.9 timeout insufficient-material draw feature. The round-25 fix correctly set the game-over status to `draw_insufficient` with `_timeoutWinnerColor=null` for the draw case, but the PGN export side still treated all `timeout` statuses as "Time forfeit". This round closes that gap: `_buildTerminationTag` now distinguishes timeout-win from timeout-draw; the last-move `{}` comment appends the new `pgn_timeout_draw_insufficient` i18n string for the draw case; `_deriveGameResult` has explicit draw_* status branches; and Termination tags were added for all terminal statuses (stalemate, 50-move, 75-move, threefold, fivefold, dead position, checkmate) that were previously missing them. New i18n key: `pgn_timeout_draw_insufficient` (zh/en). **No new permissions, no new network access, no new data collection.** This is a pure PGN-export correctness fix.

### v1.2.3 round-25: SonarCloud S6582/S3358 style cleanup + FIDE 6.9 timeout draw (pure code change)

The v1.2.3 round-25 change (2026.7.19) continues the SonarCloud style-cleanup backlog and closes a feature gap in timeout adjudication. A Python script mechanically converted 174 lines of `x && x.prop` patterns to optional chaining `x?.prop` across 8 JS files (semantically identical — only same-identifier `&&` chains converted; typeof guards and method-call chains skipped). 4 high-value nested ternaries were manually flattened to if/else chains for readability (one also fixes a latent falsy-0 bug where `mate=0` fell through to the wrong branch). The FIDE 6.9 timeout insufficient-material draw feature was added: `_onGameClockExpired` now calls `isDeadPosition(gameState)` before declaring the winner; if the position is a dead position (K vs K, K+minor vs K, K+B vs K+B same-color, K+B+B same-color vs K), the game is drawn by insufficient material instead of won on time. The clock-undo feature (round-23 Q3) was re-verified as complete. **No new permissions, no new network access, no new data collection.** The AndroidManifest, the Stockfish engine binary, the Lichess tablebase API surface, and the TLS pinning configuration are all unchanged. This is a pure code-style + feature-completeness round.

### v1.2.3 round-24: God Function split + StatsActivity license label fix (pure code change)

The v1.2.3 round-24 change (2026.7.19) continues the God Function refactoring identified in round-23. Two large ui.js functions were split into smaller, focused helpers: `_renderReviewMode` (552 → 357 lines, -35%) extracted 8 helper functions + 1 module-level const; `_reviewAnalyzeAdvance` (218 → 171 lines, -22%) extracted 2 helpers (one eliminating S1192 code duplication). `_resetGameUIState` (231 lines) was analyzed and left unchanged — it's a flat sequence of typeof guards with low cognitive complexity. Additionally, 12 historical changelog entries in `README.license` (java/com/Regalia) that incorrectly labelled `StatsActivity.java` as "AGPL v3" were corrected to "GPL v3" to match the file header (no source code change — the classification was always GPL v3). **No new permissions, no new network access, no new data collection.** The AndroidManifest, the Stockfish engine binary, the Lichess tablebase API surface, and the TLS pinning configuration are all unchanged. This is a pure code-organization + license-metadata round.

### v1.2.3 round-23: PR #51 CodeRabbit review fixes + SonarCloud triage (pure code change)

The v1.2.3 round-23 change (2026.7.19) systematically processes the 18 remaining CodeRabbit review items from PR #51 plus the SonarCloud 931-issue code-smell report (both PDFs are AI-generated; every item was verified against the actual source before any change). 16 of the 18 PR51 items are real defects and have been fixed (Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q9, Q10, Q11, Q12, Q13, Q14, Q16, Q17, Q18); 2 are false positives (Q15 — assets/README.license has no v1.2.1 manual references; Q8 — worker-pool.js's headerRe was already quote-aware). The fixes touch `HapticManager.java` (PWLE reflection removed, replaced by the public `VibrationEffect.createWaveform` API), `ui.js` / `ui-interactions.js` / `ui-gameflow.js` / `ai-bridge.js` / `tablebase.js` (PR51 functional fixes), `stats.html` (PGN tag-strip regex quote-awareness + JSON-in-HTML `<` encoding), `AndroidManifest.xml` (comment fix only — signal #2 not #1), `README.license` (license label corrections), `NOTICE`, `BUILDING.md`, `README.md`, the bilingual manuals (round-23 changelog entries), and the rebuilt `chess.html`. **No new permissions, no new network access, no new data collection.** The AndroidManifest's permission list is unchanged (INTERNET, WAKE_LOCK, VIBRATE, WRITE_EXTERNAL_STORAGE (maxSdk 28), READ_EXTERNAL_STORAGE (maxSdk 32), FOREGROUND_SERVICE, FOREGROUND_SERVICE_SPECIAL_USE, POST_NOTIFICATIONS) — round-23 only corrects a comment inside the existing `<queries>` block. The Stockfish engine binary, the Lichess tablebase API surface, and the TLS pinning configuration are all unchanged.

### v1.2.3 round-22: eval bar perspective fix (pure code change)

The v1.2.3 round-22 change (2026.7.18) fixes a user-reported bug where the
evaluation bar's advantage/disadvantage "report" (emoji + description, the
eval-delta colour, and the W/D/L labels) sometimes contradicted the player's
stance when the player played Black. Four fixes in `ui.js` / `ai-bridge.js`:
(1) the timeout/resign game-over score is now White-POV (`+∞` = White wins) to
agree with the emoji, instead of player-POV; (2) the in-app W/D/L labels are
now player-perspective ("W" = the player's win) — the PGN export stays
White-POV; (3) the eval-delta good/bad colour is now player-perspective (the
displayed numeric delta stays White-POV to match the adjacent score); (4) a
missing `total>0` guard was added to the review eval-bar WDL to prevent a
`NaN%` display if the engine ever emits `wdl 0 0 0`. **No new permissions, no
new network access, no new data collection — pure code-organization /
display-perspective fixes.**

### v1.2.3 round-21: edge-case fix (per-color gated king signal)

The v1.2.3 round-21 change (2026.7.17) fixes a user-reported edge case in the round-20 FEN-import Chess960 detection: the king-position signal in `_needsShredderFEN` is now gated per color with that color's own castling rights, so a fully legal standard position where the opponent's king has wandered off the e-file is no longer mislabeled as Chess960. **No new permissions, no new network access, no new data collection.** (Environment note: the build sandbox was reset this round; the toolchain was re-downloaded and the release signing key regenerated and backed up — the APK certificate fingerprint differs from previous rounds.)

Version: `versionCode=123`, `versionName="1.2.3"` (unchanged — same version, fix round).

### v1.2.3 round-20: 4 known leftovers resolved + hint relocation

The v1.2.3 round-20 change (2026.7.17) resolves the four documented known leftovers (castling designated-rook-file disambiguation, Chess960 detection on FEN import, removal of the unreachable DIRTY_* incremental-render subsystem, cached PWLE haptics probe), applies the actionable items of a third external review report (PGN regex hardening, Number.parseFloat, replaceAll), and relocates the batch-analysis hint to a right-aligned span inside the "Analyze All" button. **No new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted.** All changes are pure client-side logic/refactors; the haptics change only reduces redundant reflection calls against local OS APIs.

Version: `versionCode=123`, `versionName="1.2.3"` (unchanged — same version, hardening round).

### v1.2.3 round-19: 2 bilingual UX hints + log-injection fix

The v1.2.3 round-19 change (2026.7.17) adds two user-requested UI hints (a one-time startup Toast "long-press the board toggles board stabilization", and a "batch analysis in progress — long-press a move to prioritize it" line under the review eval bar while analyze-all runs) and fixes the single non-false-positive finding of two external review reports (gitar-bot / SonarCloud java:S5443: CR/LF in a rejected UCI command is now escaped before being written to logcat). **No new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted.** The hints are pure client-side UI text rendered from existing state; the log-injection fix only changes how a blocked UCI command is displayed in local logcat.

Version: `versionCode=123`, `versionName="1.2.3"` (unchanged — same version, feature + fix round).

### v1.2.3 round-18: Chess960 PGN [FEN] fix + 7-agent review (ACCESS_NETWORK_STATE removed)

The v1.2.3 round-18 change (2026.7.17) is a bug-fix + review round: the main bug fix (a newly started Chess960 game's PGN recorded the *current* position in its `[FEN]` tag instead of the *initial* position) plus the non-false-positive findings of a 7-agent line-by-line review. **One permission was REMOVED: `ACCESS_NETWORK_STATE`** — a whole-codebase audit confirmed zero usage (no `ConnectivityManager`/`NetworkCallback`/`navigator.onLine` anywhere; the WebView queries network state in its own process), so the manifest declaration was dropped per permission minimization. **No new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted.** The remaining changes are internal correctness/robustness fixes (PGN building, review/analysis state cleanup, PGN/regex parsing fixes, fsync on PGN cache save, CSP/CSS cleanup) with zero privacy impact.

Version: `versionCode=123`, `versionName="1.2.3"` (unchanged — same version, bug-fix round).

### v1.2.3 round-17: SonarCloud cleanup + God Class refactor (HapticManager / ui split)

The v1.2.3 round-17 change (2026.7.17) is a pure code-quality and code-organization change: SonarCloud-driven cleanups (`Number.*` conversions, arrow functions, `catch (Exception)` narrowing, `dataset`, `Math.trunc`, `replaceAll`, regex simplification) and a God Class refactor extracting `HapticManager.java` from StockfishNative.java plus `ui-gameflow.js` / `ui-interactions.js` from ui.js. **No new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted.** All extracted code runs with the same privileges and data access as before; the JS↔Java bridge API surface is unchanged (thin `@JavascriptInterface` delegates).

Version: `versionCode=123`, `versionName="1.2.3"` (unchanged — same version, quality/refactor round).

### v1.2.0 Phase 82+++: renderInternal AI/player/info bars extraction

The v1.2.0 Phase 82+++ change (2026.7.12) extracts 3 more rendering blocks from `renderInternal()` into dedicated functions: `_renderAIBar(h, oppC)`, `_renderPlayerBar(h)`, and `_renderInfoBars(h)`. `renderInternal()` was further reduced from 476 to 359 lines. This is a pure code-organization change — **no new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted**. All extracted functions use global state only (with `oppC` passed as a parameter where needed); the `h` string concatenation pattern is preserved.

Version: `versionCode=120`, `versionName="1.2.0"` (unchanged — same version, deeper refactor).

### v1.2.0 Phase 82++: renderInternal main-board extraction

The v1.2.0 Phase 82++ change (2026.7.12) extracts 4 more rendering blocks from `renderInternal()` into dedicated functions: `_renderHeader()`, `_renderBoardGrid(h, flip, cm)`, `_renderSetupPanel(h)`, and `_renderSidePanel(h, infoSq, infoCtrl, oppC)`. `renderInternal()` was further reduced from 619 to 476 lines. This is a pure code-organization change — **no new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted**. All extracted functions use global state only (with `flip`, `cm`, `infoSq`, `infoCtrl`, `oppC` passed as parameters where needed); the `h` string concatenation pattern is preserved.

Version: `versionCode=120`, `versionName="1.2.0"` (unchanged — same version, deeper refactor).

### v1.2.0 Phase 82+: renderInternal review mode extraction

The v1.2.0 Phase 82+ change (2026.7.12) extracts the entire review-mode rendering block from `renderInternal()` (615 lines) into a new `_renderReviewMode(h)` function. `renderInternal()` was further reduced from 1,224 to 619 lines. The block renders the complete review-mode overlay (board, eval bar, slider, chart, nav buttons, analyze button). This is a pure code-organization change — **no new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted**. The extracted function uses global state only; the `h` string concatenation pattern is preserved. The early-return path (invalid review state) is handled via a `{h, done}` return value so the caller can skip stale-DOM scroll-save/restore logic.

Version: `versionCode=120`, `versionName="1.2.0"` (unchanged — same version, deeper refactor).

### v1.2.0 Phase 81-83: Deep refactor continuation (EngineConfigHelper + renderInternal split + review board fix)

The v1.2.0 Phase 81-83 changes (2026.7.11) continue the architecture refactor. `StockfishNative.java` was further reduced from 4,492 to 4,245 lines by extracting engine configuration methods into a new `EngineConfigHelper.java` (13th helper class). `renderInternal()` in `ui.js` was reduced from 1,365 to 1,224 lines by extracting 8 modal dialog blocks into `_renderDialogs(h)`. The review board display regression (Phase 77's flex-layout coordinate labels breaking the CSS Grid) was fixed. This is a pure code-organization + bug-fix change — **no new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted**. Specifically:

- **Engine configuration methods** (`setAutoConfig`, `detectHardwareAndConfigure`, `applySettings`, `setEngineThreads`, `setEngineHash`, `setEngineMoveOverhead`, `setEngineMultiPV`, `setEnginePonder`, `setEngineShowWDL`, `setEngineSkillLevel`, `setEngineLimitElo`, `setElo`, `setGameDifficulty`, `forceFullStrength`, `syncGameDifficulty`, etc.) moved from `StockfishNative.java` to `EngineConfigHelper.java`. Logic unchanged — all range capping (threads ≤ 2×CPU cores, hash ≤ 50% JVM heap, moveOverhead ≤ 1000ms, multiPV ≤ 8, skillLevel 0-20, elo 500-3500) and big.LITTLE hardware detection are preserved. All `@JavascriptInterface` method signatures on `StockfishNative` are preserved as thin delegates.
- **Modal dialog rendering** (new game, engine config, resign confirm, about, import, promotion, save PGN, PGN cache manager) extracted from `renderInternal()` into `_renderDialogs(h)`. Logic unchanged — the `h` string concatenation pattern is preserved.
- **Review board coordinate label fix** (Phase 83): The Phase 77 flex-layout label wrappers inside `.bgrid` (CSS Grid) broke the 64-cell grid layout. Fixed by moving labels to `position:absolute` siblings of `.bgrid`. This is a pure visual/layout fix — no data implications.

Version: `versionCode=120`, `versionName="1.2.0"` (unchanged — same version, deeper refactor).

### v1.2.0 Phase 73-80: Architecture refactor (God Module split)

The v1.2.0 architecture refactor (2026.7.11) restructured the codebase to reduce technical debt. `StockfishNative.java` was split into 11 manager/helper classes, and `ui.js` was split into 4 JS modules + `_computeAndCacheVisualAnnotations` was decomposed into 4 sub-functions + `_buildEvalTrendSVG` was decomposed into 6 sub-functions. This is a pure code-organization change — **no new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted**. Specifically:

- **File I/O operations** (`writeTextFile`, `readTextFile`, `listFiles`, `loadAssetAsBase64`, etc.) moved from `StockfishNative.java` to `FileIoHelper.java`. The `loadAssetAsBase64` method gained a `..` path-traversal check (defense-in-depth; the only existing call site uses a literal `'AGPLv3_Logo.svg'` which is unaffected).
- **Permission checks** (`hasStoragePermission`, `requestStoragePermission`, `hasNotificationPermission`, `requestNotificationPermission`) moved to `PermissionHelper.java`. Logic unchanged.
- **Haptic feedback** moved to `HapticHelper.java`. Logic unchanged.
- **SAF file picker operations** (export settings/PGN, import settings/PGN, cancel pending export) moved to `SafPickerHelper.java`. Logic unchanged — the PGN import 5000-line truncation guard and control-character sanitization are preserved.
- **Engine settings query/export/import** (`getEngineInfo`, `getEngineSettings`, `exportSettings`, `exportEngineSettings`, `importSettings`, `importEngineSettings`) moved to `EngineSettingsHelper.java`. Logic unchanged — the Phase 71 range capping (threads ≤ 2×CPU cores, hash ≤ 50% JVM heap, moveOverhead ≤ 1000ms) and autoConfig-override-on-explicit-import behavior are preserved.
- **PGN cache CRUD** moved to `PgnCacheManager.java`. Logic unchanged.
- **MessageBus.java** and **state-store.js** are new infrastructure for unified JS↔Java communication and global state management. They process only in-memory game state (board positions, move lists, UI preferences) — no personal data, no network access.
- **Review board coordinate labels** (Phase 77): Added left 1-8 rank labels, top a-h file labels, and per-square coordinate labels to the review-mode board. This is a pure visual enhancement — no data implications.

Version: `versionCode=120`, `versionName="1.2.0"`.

### v1.2.0 Phase 72: review analyze-all "false completion" bug fix

The Phase 72 change (2026.7.12) is a pure bug fix in `_reviewAnalyzeAdvance` (ui.js) — the review-mode "Analyze All" batch completion check. No new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted. The fix only affects the in-memory `_reviewEvalCache` scan logic (when to stop the batch and report completion). Version unchanged: `versionCode=120`, `versionName="1.1.2"`.

### v1.2.0 Phase 71: CSP relaxation + XSS hardening on stats page

The stats page (`stats.html`) Content-Security-Policy was relaxed from a fixed SHA-256 hash to `'unsafe-inline'` (Phase 71, 2026.7.11) to unblock the 23 inline `onclick` event handlers used for move selection (the previous hash-based policy silently blocked them per CSP Level 2+). This is safe because:

- `stats.html` is a local asset (`file:///android_asset/`) with no externally injected content.
- All JavaScript in `stats.html` is inlined — no external script loading.
- The `connect-src 'none'` directive remains, preventing any network fetch from the stats page.
- As defense-in-depth, all unrecognized movetext/variation-text/notation characters are now HTML-escaped via `_escFEN` before insertion into `innerHTML`, neutralizing any `<img onerror>`, `<script>`, or similar payload that might be present in a user-pasted PGN. No user data leaves the device — the hardening is purely a local-rendering safety measure.

No new permissions, no new network access, no new data collection. Version unchanged: `versionCode=120`, `versionName="1.1.2"`.

### v1.2.1 fourth-pass: Round-4 cleanup — dead-code purge (2026.7.13)

The v1.2.1 fourth-pass refinement (2026.7.13) is a first-principles cleanup that reverts the third-pass "unused-file activation" round (above) and slimms two manager classes. **No new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted.** Specifically:

- **Deleted 7 files** (3 Java + 4 JS): `MessageBus.java` / `UciProtocolHandler.java` / `EngineConfigManager.java` / `ui-audio.js` / `ui-board.js` / `ui-review.js` / `ui-toolbar.js`. These were Phase-73/74 extracts that duplicated inline logic in `StockfishNative.java` / `ui.js` / `ai-bridge.js` with subtly different conventions (rank order, move taxonomy, audio state, ELO ranges). The third-pass "activation" wired them in via `typeof` guards and `try-catch` wrappers, but the activation was "for activation's sake" — no user-facing feature depended on them, and several introduced semantic-drift risks.
- **Slimmed 2 files**: `EngineHealthMonitor.java` (208 → 85 lines) and `EngineProcessManager.java` (489 → 111 lines). The deleted methods (heartbeat thread, zombie detection, `extractEngineFromApk`, `startProcess`, etc.) were all dead code — `StockfishNative` keeps its own inline copies for direct field access.
- **TlsSecurityHelper.validatePin retained**: The actual SPKI SHA-256 pin validation implemented in the third pass is KEPT (it was a real security improvement; only the dead-code activation was reverted).
- **Bug fix retained and propagated**: `StockfishNative.extractEngineFromApk` (inline) now guards against `ZipEntry.getSize() == -1` — the same fix that had been applied only to the now-deleted `EngineProcessManager.extractEngineFromApk` copy.

No user data is collected, stored, or transmitted by any of these changes. The cleanup reduces the codebase by ~1,300 lines and eliminates 7 dead modules.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged — same-version refinement).

### v1.2.1 fifth-pass: Round-5 review — line-by-line audit of remaining 28 files (2026.7.13)

The v1.2.1 fifth-pass refinement (2026.7.13) is a first-principles line-by-line audit of all remaining 19 Java files + 9 JS files. **No new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted.** Specifically:

- **Removed 2 unused imports**: `ChessApp.java` and `ChessWebViewClient.java` each had a leftover `import android.os.Build;` that was never referenced after earlier refactors. Pure dead-code removal — no behavioral change.
- **Bug fix**: `EngineSettingsHelper.importSettings` — the `engine.elo` case used a 1-3200 range, inconsistent with `EngineConfigHelper`'s canonical 500-3500 range. Importing a value like 400 would pass the 1-3200 check, then be silently re-clamped to 500 on the next `setEngineLimitElo` call. Fixed to `Math.max(500, Math.min(3500, ...))`. **No user data is transmitted** — the fix only affects local ELO validation on settings import.
- **Verified clean**: All other 16 Java files and all 9 JS files were audited line-by-line. No dead code, no inconsistent ranges, no leftover debug statements, no references to deleted symbols, no `debugger;` statements, no `TODO`/`FIXME`/`HACK` markers.

No user data is collected, stored, or transmitted by any of these changes.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged — same-version refinement).

### v1.2.1 sixth-pass: Round-6 review — stats page visual annotation bug fix (2026.7.13)

The v1.2.1 sixth-pass refinement (2026.7.13) fixes a user-reported bug where the statistics page's visual annotations section was silently hidden for all newly-played games. **No new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted.** Specifically:

- **Bug fix**: `openStatsPage()` (ai-bridge.js) now sends a `visualAnnotations` field in the payload to the stats page, containing all visual annotation cache entries (both imported and auto-generated). The stats page uses this field as the primary data source instead of scanning the PGN text (which only contained imported annotations per the Phase 62 design). **No user data is transmitted** — the visual annotations are computed locally from the board state and were already displayed in the review board; this fix merely makes them visible in the stats page too.

No user data is collected, stored, or transmitted by this change.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged — same-version refinement).

### v1.2.1: Hardening + bug-fix revision (same version line)

The v1.2.1 release (2026.7.13) is a hardening + bug-fix revision. **No new permissions, no new network access, no new data collection, no changes to how data is stored or transmitted.** Specifically:

- **JsBridgeGateway sandbox path check hardened**: `isPathInSandbox()` now requires a trailing `File.separator` before `startsWith`, closing a theoretical directory-traversal where `/data/data/com.Regalia/files_evil/x` could pass the `filesDir` check. No file ever left the sandbox in practice — the fix is defense-in-depth.
- **SAF persistable URI permission grants removed**: One-shot PGN/settings import/export operations no longer call `takePersistableUriPermission`. The transient `FLAG_GRANT_READ/WRITE_URI_PERMISSION` from the SAF picker Intent is sufficient and no longer consumes the 512-grant cap. **No data leaves the device; the change reduces standing app privileges.**
- **PGN cache name input validation**: The `prompt()` for PGN cache name now enforces a 60-character length cap and rejects filesystem-dangerous characters (`/ \ : * ? " < > |` and control characters), matching the existing validation in `_renameHumanPlayer`.
- **Engine thread-death detection**: `ChessApp`'s `UncaughtExceptionHandler` now sets a static flag via `StockfishNative.markEngineThreadDead(threadName)` when an `SF-*` engine thread dies. The heartbeat monitors this flag and triggers `recoverEngine()` — previously, a dead reader thread could leave the engine process alive but unresponsive, manifesting as a 15–30s silent hang. **No data is collected or transmitted** — the flag is in-memory only and reset on successful engine restart.
- **`_restartInProgress` stale-detection**: `recoverEngine()` and `restartEngine()` now reset the restart lock if it has been stuck for >30s (e.g., the inner executor task was silently discarded by `shutdownNow()`). Pure reliability fix — no data implications.
- **`_discardingPonderBestmove` TOCTOU**: `stopAndWaitForBestmove()` and the bestmove reader thread now clear the discard flag in the early-return and latch-capture paths, preventing the flag from being stuck `true` and silently discarding the next legitimate bestmove (manifesting as "AI never moves"). Pure reliability fix.
- **Chess960 re-apply symmetry**: After an engine crash/recovery, `UCI_Chess960` is now re-applied as both `true` AND `false` based on `_pendingChess960` — previously only `true` was re-applied, so a user who switched from Chess960 back to standard chess could have `UCI_Chess960=true` erroneously retained after a crash.
- **eval-mode option leak fix**: `engineStop()` now calls `restoreGameplayOptions()` if it interrupts a `STATE_EVAL` search, preventing `Contempt=0` / `MultiPV=1` / `UCI_AnalyseMode=true` from leaking into the next gameplay search. Pure gameplay-correctness fix.
- **`sendSetOptionAndWait` newline hardening**: The `value` parameter is now stripped of `\r` / `\n` before concatenation into the UCI command, matching the parallel hardening applied to `UciProtocolHandler.setOptionAndWait` in v1.2.0. Prevents UCI command injection via a malicious option value.
- **Checkmate WDL inversion fix**: The fast-path WDL cache writes in `requestEngineEval` and `_requestBatchEval` now write `wdlW=1000` (not 0) when Black is checkmated, matching the White-POV swap in `onEngineEval`'s normal path. The eval bar and PGN `[%eval #N]` tags now display correct WDL percentages for mate positions.
- **`[%eval #N]` tag format fix**: `formatEvalAnnotation` now defaults `absMd` to 1 (matching `formatEvalTag`) when `mateDist=0` but `|eval|≥90000`, eliminating malformed `[%eval #+]` / `[%eval #-]` tags that some PGN readers reject.
- **`onBestMove` validation order**: UCI move parsing and piece-existence checks now run BEFORE clearing `isAIThinking` / `_aiSafetyTimerId` / `_aiRetryCount`, so an unparseable bestmove keeps the safety timer active for retry instead of leaving the AI in a "not thinking, no safety timer, but still AI's turn" deadlock.
- **CSS `font-family` entity fix**: The 5 `&#x27;` HTML entities inside `<style>` rules in `index.html.tpl` (which the HTML parser does NOT decode in raw-text mode) have been replaced with literal `'` characters. The chess pieces, review pieces, promotion buttons, setup buttons, and move-animation overlay now correctly use the documented `'DejaVu Sans','Noto Sans','Segoe UI Symbol'` font stack instead of falling back to the inherited font.
- **`StatsActivity.onDestroy` parity**: Added `webView.stopLoading()` as the first step of WebView teardown, matching `MainActivity.onDestroy` — prevents a SIGSEGV on certain OEM ROMs (HyperOS 3, MIUI) when the WebView dispatches a load callback to a destroyed native peer.
- **`HapticHelper` system-setting check**: The main-game haptic feedback now respects the system `HAPTIC_FEEDBACK_ENABLED` setting, matching `StatsActivity.performHaptic` — previously the main game vibrated even when the user had disabled system haptic feedback.
- **`EngineProcessManager.extractEngineFromApk` divide-by-zero guard**: `ZipEntry.getSize()` may return -1 (unknown size); the progress percentage calculation now falls back to a fixed 25% in that case instead of producing negative/incorrect values.

Version: `versionCode=121`, `versionName="1.2.1"`.

## Permissions

| Permission | Purpose | Required |
|-----------|---------|----------|
| INTERNET | Tablebase API queries | No (only for tablebase feature) |
| ~~ACCESS_NETWORK_STATE~~ | ~~Detect offline status~~ | Removed in v1.2.3 round-18 (zero usage in codebase) |
| WAKE_LOCK | Keep engine process alive during analysis | Yes (foreground service) |
| VIBRATE | Haptic feedback (personified per-piece haptics, v1.0.8+) | No |
| FOREGROUND_SERVICE | Engine stability notification | Yes (Android 14+) |
| FOREGROUND_SERVICE_SPECIAL_USE | Engine foreground service type (`specialUse`, Android 14+) | Yes (Android 14+) |
| POST_NOTIFICATIONS | Engine foreground service notification (Android 13+) | Yes (Android 13+, runtime-requested) |
| READ_EXTERNAL_STORAGE | PGN file import from shared storage (legacy, `maxSdkVersion=32`) | No (SAF used on Android 13+) |
| WRITE_EXTERNAL_STORAGE | PGN/settings file export to shared storage (legacy, `maxSdkVersion=28`) | No (SAF used on Android 9+) |

> **Note on sensors (v1.0.5+):** The board anti-shake feature (`StabilizationHelper.java`) reads the `TYPE_LINEAR_ACCELERATION` sensor for OIS-style translation compensation. This sensor does **not** require any Android permission and the raw motion data is **never** stored or transmitted — it is consumed in real time to apply a `transform: translate()` on the board element and discarded. No permission declaration is needed in the manifest for this sensor.

> **Note on the wake lock (v1.1.0 Phase 57+):** The `EngineService` foreground service acquires a partial wake lock with a **30-minute timeout** as a safety net. If the OEM silently kills the service and `onDestroy` never runs, the wake lock is released automatically after 30 minutes — preventing indefinite CPU wake on misbehaving OEM ROMs. The lock is acquired **once** in `onCreate()` with the 30-minute timeout and is **not** re-acquired by `onStartCommand`, so 30 minutes after acquisition the CPU may sleep again (wording corrected in round-43 per the round-42 42-4 comment fix — an earlier version of this note claimed longer sessions re-acquire the lock; they do not).

## Haptic Feedback (v1.0.8+)

v1.0.8 introduces personified haptic feedback — each of the six piece types (pawn, knight, bishop, rook, queen, king) plus castling and promotion has a dedicated vibration pattern. Haptics are:

- Triggered locally via `Vibrator`/`VibrationEffect` (API 26+) or PWLE (API 35+)
- Controlled by the user's system haptic-feedback preference (`Settings → Sound & vibration → Haptic feedback`)
- Throttled per-event-type to avoid vibration fatigue
- Never recorded or transmitted — the vibration is the only output

## Engine Binary Integrity

The Stockfish 18 engine binary (`libstockfish.so`) is shipped as an arm64-v8a native library inside the APK. On first launch, `StockfishNative.java` validates the binary:

- **ELF magic check** (first 4 bytes = `\x7fELF`) — guards against corrupted or non-ELF files.
- **Minimum-size check** (5 MB; lowered from 50 MB in round-44, A16) — the genuine Stockfish 18 binary is ~114 MB; truncated or stub files are rejected.

The known-good SHA-256 of the official Stockfish 18 arm64-v8a-dotprod binary
(`8f7116d3f1a7004a6581d4fb0c1ff891ce095bab6d45e52f1578897cf23b61b5`) is
documented in BUILDING.md and is verified three-way (source file / deployed
jniLibs copy / APK-embedded library) in every release round; the app itself
performs the ELF + size checks above at runtime (this section was corrected
in round-43 — it previously claimed a baked-in SHA-256 runtime check that
the current code does not perform).

If either check fails, the engine refuses to start and reports the error to the user via the UI. The binary is never downloaded at runtime; it is statically embedded in the APK.

## v1.2.3 round-13 refinement (2026.7.16)

The round-13 refinement re-enabled CMake (resolving the round-12 build workaround) and applied a comprehensive first-principles per-file/per-line code review using 6 parallel review agents. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal bug fixes and robustness improvements with zero privacy impact:

- **`JsBridgeGateway.java` UCI command injection guard (P0)**: Added CR/LF rejection in `isUciCommandAllowed` before the whitelist lookup. A JS caller could previously inject arbitrary UCI commands (including `quit`) via `sendToEngine("setoption name X value 1\nquit")`. No privacy impact — defense-in-depth for engine process integrity.
- **`StockfishNative.java` restartEngine fix (P0)**: Reset `shutdownRequested` flag after `shutdown()` so `startEngine()` can proceed. Previously, a user-initiated engine restart would leave the engine permanently dead. No privacy impact — internal engine lifecycle fix.
- **`StockfishNative.java` _evalDeepBatchActive clear (P1)**: Added `_evalDeepBatchActive = false` to `cleanupEngineResources()` so a crashed engine doesn't leak the batch flag to the new engine, producing biased eval results. No privacy impact — internal correctness fix.
- **`SafPickerHelper.java` + `StatsActivity.java` openInputStream null-check (P1)**: `ContentResolver.openInputStream(Uri)` can return null; two read methods now throw a descriptive `IOException` instead of a confusing NPE. No privacy impact — better error diagnostics for file imports.
- **`StabilizationHelper.java` registerListener return check (P1)**: Now checks `SensorManager.registerListener` return value; logs a warning on failure instead of silently reporting stabilization as active. No privacy impact — sensor anti-shake feature reliability.
- **`AndroidManifest.xml` `<queries>` element (P1)**: Added targeted `<queries>` block listing 12 root-detection package names so `RootDetector.checkRootPackages` works on Android 11+ (API 30+ package visibility restrictions). No privacy impact — the root detection is informational-only (app never refuses to run on rooted devices); the `<queries>` declaration is a manifest-level visibility grant, not a new permission. The declared packages are common root-detection app package names (Magisk, SuperSU, etc.) — declaring them does NOT install or query them unless they're already present on the device.
- **`ChessWebViewClient.java` render-crash fallback UI (P1)**: After 4+ render-process crashes in 60s, the user now sees a bilingual recovery message instead of a frozen screen. No privacy impact — UX improvement.
- **`ChessWebViewClient.java` fallback context (P2)**: When opening an external URL and the Activity is destroyed, now uses `getApplicationContext()` instead of the dead Activity context. No privacy impact — prevents silent URL-open failures.
- **`ui.js` gameClockTimerId cleanup (P1)**: Added `clearInterval(gameClockTimerId)` to `_cleanupEventListeners` so a timed game's 200ms interval doesn't keep firing after Activity destroy. No privacy impact — resource cleanup.
- **`StockfishNative.java` PROCESS_DESTROY_GRACE_MS alignment (P2)**: `shutdown()` now uses the named constant instead of a bare `200` literal. No privacy impact — consistency fix.
- **`PgnCacheManager.java` delete return value (P2)**: Now returns `true` if any deletion occurred (PGN and/or tags), not only when the PGN file was deleted. No privacy impact — accurate batch-deletion counting.
- **`eco-data.js` cache pollution guard (P2)**: Added `if(_ecoData.length>0)` guard before saving to IndexedDB, preventing a parse failure from overwriting valid cached data with an empty array. No privacy impact — ECO data is bundled in the app (not user data); the cache is a performance optimization.
- **`tablebase.js` variation moveNum offset (P2)**: Applied `_importedStartMoveNum` offset to relocated variation move numbers so they display correctly for FEN-started games. No privacy impact — display correctness.
- **`build.gradle` empty-keystore-path guard (P2)**: Added `!releaseKeystorePath.isEmpty()` check. No privacy impact — better error message for fresh checkouts.
- **`gradle.properties` dead property removal (P2)**: Removed `android.enablePngCrunchInReleaseBuildsLibs=false` (not a recognized AGP property). No privacy impact — config cleanup.
- **`build-chess.py` dead CSP hash block removal (P2)**: Removed the stats.html CSP sha256 hash auto-update block (stats.html now uses `'unsafe-inline'`). No privacy impact — dead code removal.
- **`AndroidManifest.xml` allowBackup resolution (P2)**: Removed `android:fullBackupContent` and `android:dataExtractionRules` attributes (dead config when `allowBackup="false"`). The two XML rule files are retained in `res/xml/` for reference. No privacy impact — `allowBackup="false"` (the documented v1.0.4 design decision) is unchanged; the app still does not participate in Android backup/restore. Removing the dead references just makes the manifest accurately reflect the actual behavior.
- **P3 cleanup (stale comments, dead code)**: 11 minor fixes across `MainActivity.java`, `EngineService.java`, `TlsSecurityHelper.java`, `network_security_config.xml`, `ai-bridge.js`, `FileIoHelper.java`, `StockfishNative.java`, `EngineConfigHelper.java`, `tablebase.js`, `pgn-standard.js`. All are documentation-only or dead-code removal. No privacy impact.

Version: `versionCode=123`, `versionName="1.2.3"` (unchanged — bug-fix round, no version bump).

## v1.2.3 round-12 refinement (2026.7.16)

The round-12 refinement addresses two open SonarCloud bugs and applies a first-principles code review guided by three uploaded PDFs (AI code-gen defect prevention, Android WebView dev, SonarCloud pass guide). **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **`game-logic.js` + `ui.js` slider aria-label (SonarCloud Bug #1, Web:InputWithoutLabelCheck)**: The review-mode slider's `<input type="range">` overlay (transparent, handles touch/keyboard) now uses a descriptive `aria-label` (`T('review_move_slider')` → "复盘步数" / "Review move number") instead of the terse `T('step_label')` ("Step" / "第"). WCAG 2.1 Level A 4.1.2 (Name, Role, Value) compliance. No privacy impact — accessibility-only change.
- **`StockfishNative.java` InterruptedException handling (SonarCloud Bug #2, java:S2142)**: `recoverEngine()` auto-recovery sleep now restores `Thread.currentThread().interrupt()` + clears the restart lock + returns early on `InterruptedException`. Previously the catch (Throwable t) swallowed the interrupt flag, risking engine process leaks on shutdown. No privacy impact — internal concurrency hardening.
- **`build.gradle` CMake workaround**: `externalNativeBuild` blocks temporarily commented out due to AGP 8.7.3 + CMake 3.22.1 re-run loop bug ("manifest 'build.ninja' still dirty after 100 tries"). `libengine_bridge.so` pre-built with the same NDK r27c clang++ + flags and placed in `jniLibs/`. No source code (CMakeLists.txt, engine_jni.cpp) changes. No privacy impact — build-time workaround only.
- **First-principles code review**: Audited all 11 `Thread.sleep` / `Thread.join` locations in `StockfishNative.java` (all now consistent), all 93 `@JavascriptInterface`-annotated methods (all properly annotated), `MainActivity.java` WebView setup (fully aligned with PDF best practices: `setAllowFileAccess(false)`, `MIXED_CONTENT_NEVER_ALLOW`, Safe Browsing, full `onDestroy` cleanup), 27 empty catch blocks in JS modules (all narrow defensive catches with intent-documenting comments). No additional changes needed — codebase already polished through v1.2.1's 11 rounds + v1.2.2's 8 rounds + v1.2.3's prior optimization pass.

Version: `versionCode=123`, `versionName="1.2.3"` (unchanged — bug-fix round, no version bump).

## v1.2.1 round-7 refinement (2026.7.13)

The seventh-pass refinement is a code-quality and security-hardening pass. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **PGN export semantics change**: Reverting the Phase 62 `imported`-flag filter in `_buildPGNString()` does NOT change what data is collected or stored — it only changes which annotations are included when the user explicitly chooses "Yes, include special annotations" in the export dialog. The user's existing annotation cache is unaffected; only the export output includes more annotations when the user opts in.
- **`secureRandomInt()` fail-safe**: When the `crypto` API is unavailable (theoretical scenario — Android WebView has supported Web Crypto API since 2015), the function now returns `0` instead of falling back to `Math.random()`. This is a security improvement (no predictable PRNG for Chess960 SP-ID selection) with no privacy impact.
- **`postJsCallback` structured API**: The new `postJsCallback(String eventName, Object... args)` overload is an internal Java-to-JS bridge helper. It does not access, store, or transmit any new data. Existing call sites are unchanged.
- **ELO range unification**: `setConfigElo()` JS-side clamp changed from 500-3200 to 500-3500 to match the Java side. This fixes a data-consistency bug where imported ELO values 3201-3500 were accepted by Java but not representable in the UI. No new data is collected; the change only ensures the UI can display all values Java accepts.
- **`onBestMove` terminal-position probe**: When the engine returns `(none)` (no legal move), the app now checks `gameStatus()` and applies game-over immediately for terminal positions. This is a reliability fix (prevents up to 18-minute hang) with no privacy impact.
- **`_deepClone` depth guard**: Defensive programming to prevent stack overflow on pathological inputs. No privacy impact.
- **`proguard-rules.pro` creation**: Build infrastructure file. The Log.v/Log.d stripping rule actually *improves* privacy by removing verbose/diagnostic logging from release builds (only w/i/e levels are retained for crash diagnostics).

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged).



## v1.2.1 round-8 refinement (2026.7.13)

The eighth-pass refinement fixes a critical white-screen bug in `state-store.js`. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **TDZ (Temporal Dead Zone) bug fix**: The round-7 `_deepClone()` hardening added a `const DEEP_CLONE_MAX_DEPTH = 64;` declaration at a position in the IIFE that came AFTER the IIFE-top initialization call `let _state = _deepClone(_initialState);`. Because `const` declarations do NOT hoist (they are in TDZ until their declaration line executes), the function body's reference to `DEEP_CLONE_MAX_DEPTH` triggered `ReferenceError: Cannot access 'DEEP_CLONE_MAX_DEPTH' before initialization`, crashing the state-store module initialization, cascading to all dependent modules (ui.js, ai-bridge.js, etc.), and leaving the WebView showing only the background color. The fix moves the `const` declaration to IIFE-top, BEFORE the initialization call. This is purely a code-organization fix with no privacy impact.
- **`build.gradle` alignment**: Two latent build-config mismatches were corrected so the round-8 APK can be assembled cleanly on a fresh environment:
  - Pinned `ndkVersion "27.2.12479018"` (AGP's default 27.0.12077973 was incomplete on fresh install).
  - Set `useLegacyPackaging true` in `packagingOptions.jniLibs` to match `android:extractNativeLibs="true"` in `AndroidManifest.xml`. This keeps `.so` files uncompressed in the APK so the system can memory-map them at install time — no behavioral or privacy impact (the .so is the same Stockfish 18 arm64-v8a-dotprod binary, just stored differently inside the APK).
- **No new logging, no new telemetry, no new file I/O.**

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged).


## v1.2.1 round-9 refinement (2026.7.13)

The ninth-pass refinement is a code-quality and hardening pass based on a first-principles code review of all source files (~32K lines), guided by three uploaded PDFs (AI code-gen defect prevention, Android WebView dev, SonarCloud pass guide). **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **AndroidManifest FGS subtype property**: Added `<property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="chess_engine_analysis" />` to EngineService. This is a required declaration for `FOREGROUND_SERVICE_TYPE_SPECIAL_USE` on Android 14+ — it identifies the foreground service subtype to the system. No privacy impact (the value is a static string embedded in the manifest; not user data).
- **StockfishNative lock fix + cleanupEngineResources state reset**: Internal concurrency hardening. No privacy impact.
- **ai-bridge.js _attachDivergentPV return check**: Correctness fix for PGN variation SAN. No privacy impact.
- **Cross-module export-list corrections** (5 JS files): No runtime impact (bundled mode strips the export line). No privacy impact.
- **state-store.js reset deep-clone + dialog payload guard**: Internal state-management hardening. No privacy impact.
- **chess960.js null guards**: Defensive programming. No privacy impact.
- **pgn-standard.js escaped-quote regex**: PGN parsing correctness. No privacy impact.
- **ai-bridge.js + eco-data.js error logging**: Empty `catch(e){}` blocks now log via `console.warn`. Logs are local-only (Android logcat, not transmitted). No new data collection — the errors were previously silently swallowed; now they're visible for debugging.
- **game-logic.js malformed key guard**: Internal validation. No privacy impact.
- **StatsActivity + SafPickerHelper openOutputStream null check**: Error-message clarity improvement. No privacy impact.
- **EngineProcessManager ChmodProvider slim**: Dead interface method removal. No privacy impact.
- **build.gradle FileInputStream leak fix**: Resource leak fix in build script. No runtime/privacy impact.
- **index.html.tpl CSP hardening**: Added `form-action 'none'` and `object-src 'none'` to CSP. Both fall back to `default-src 'none'` (behavior unchanged), but explicit declarations are defense-in-depth. The WebView dev guide PDF emphasized CSP hardening as a core security practice.
- **index.html.tpl + tablebase.js + ui.js redundancy cleanup**: Stale comment fixes, dead code removal. No privacy impact.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged).


## v1.2.1 round-10 refinement (2026.7.14)

The tenth-pass refinement is a deep fix of the P2/P3 items flagged by round-9's review-D (StockfishNative.java), review-E (16 mid-size Java files), and review-F (build infra + manifest + proguard). 13 priority items implemented. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **StockfishNative.java concurrency hardening** (`_restartInProgress` lock consistency, `recoverEngine` shutdown-requested checks, `_discardingPonderBestmove` lock unification): Internal threading hardening. No privacy impact.
- **URL scheme case-insensitivity** (3 sites: `StockfishNative.openUrlInBrowser`, `StatsActivity.openUrlInBrowser`, `ChessWebViewClient.shouldOverrideUrlLoading`): The check now accepts `"HTTP://..."` (case-insensitive scheme per RFC 3986 §3.1). No privacy impact — the same set of URLs is accepted/rejected, just case-insensitively.
- **StatsActivity `statsPayload` volatile + `onPause`/`onResume`**: Internal threading fix + battery optimization (backgrounded stats page now pauses JS timers). No privacy impact.
- **EngineConfigHelper `detectBigCoreCount` failure-cache fix + mid-search comments**: Internal retry logic. No privacy impact.
- **StabilizationHelper `applyTransform` hot-path optimization**: Performance fix. No privacy impact.
- **TlsSecurityHelper `validatePin` constant-time comparison**: Pin comparison now uses `MessageDigest.isEqual` instead of `String.equals`. The pins are public Let's Encrypt values (not user data). No privacy impact — purely a defensive coding practice.
- **HapticHelper.java removed entirely**: Dead-code purge. The class was instantiated but never invoked. No behavior change. No privacy impact.
- **StockfishNative.java P3 cleanup** (magic numbers extracted, `escapeJsString` dead-code simplified, `isProcessAlive` `SDK_INT` pre-check, `_pendingChess960` field relocated, `if(ctx==null)` dead code removed, "remove JNI bridge" comment rewritten): Readability + minor performance. No privacy impact.
- **build.gradle cleanup** (pickFirsts removed libfoundation.so, lint disable list dedup with lint.xml): Build config cleanup. No runtime/privacy impact.
- **AndroidManifest.xml**: Removed `android:requestLegacyExternalStorage="true"`. This attribute was already ignored (targetSdk=35 ≥ 30) and the app uses SAF for all file I/O. No behavior change, no privacy impact.
- **proguard-rules.pro**: Comment rewrite for clarity. No rule changes. No privacy impact.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged).


## v1.2.1 round-10 continuation (2026.7.14)

This pass addresses the remaining review-E items not in the initial round-10 priority list. 4 secondary items implemented. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **FileIoHelper naming fix** (`ensureReadExternalStoragePermission` → `requestReadExternalStoragePermission`): Pure rename for accuracy. The method's behavior (asynchronously request the READ_EXTERNAL_STORAGE permission dialog) is unchanged. No privacy impact.
- **PermissionHelper request-code migration** (1001/1003 → 3001/3002): The numeric codes passed to `Activity.requestPermissions` are changed to a disjoint 3000-range so they no longer overlap with `SafPickerHelper`'s `startActivityForResult` codes (1001-1004). The codes are never transmitted off-device; they are internal dispatch identifiers. No privacy impact.
- **ChessApp / MainActivity / StockfishNative version-string unification**: Three hardcoded `"v1.2.1"` literals replaced with `BuildConfig.VERSION_NAME` (auto-generated by AGP from `build.gradle`'s `versionName`). The version string was already visible in logs and the title display; this change just makes it auto-sync with `build.gradle`. No privacy impact — the version number is not sensitive data.
- **EngineService `isRunning` timing fix**: Moved `isRunning = true` to after `startForeground()` succeeds. Pure internal state-management improvement; no user-visible behavior change. No privacy impact.
- **ChessWebViewClient doc-comment update**: Documentation-only change. No privacy impact.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged).


## v1.2.1 round-10 regression test + first-principles optimization (2026.7.14)

This pass performs a regression test of all review-D/E/F fixes from the initial round-10 and its continuation, then applies first-principles optimization to eliminate residual magic numbers, redundant operations, and misleading comments discovered during the regression audit. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **Regression test**: All review-D/E/F fixes verified intact — `_restartInProgress` lock consistency (14 writes), `recoverEngine` shutdown checks, `_discardingPonderBestmove` lock unification (8 writes), URL scheme case-insensitivity (3 sites), HapticHelper removal, StatsActivity volatile + lifecycle, EngineConfigHelper retry, StabilizationHelper hot-path, TlsSecurityHelper constant-time, FileIoHelper rename, PermissionHelper 3000-range codes, BuildConfig.VERSION_NAME unification, EngineService isRunning timing, build.gradle cleanup, AndroidManifest cleanup, proguard-rules comment fixes. No privacy impact — purely a verification pass.
- **StockfishNative.java `PROCESS_DESTROY_GRACE_MS` extraction**: 2 remaining `Thread.sleep(100)` calls in process-destroy paths extracted to a named constant (semantically distinct from `PONDER_STOP_GRACE_MS`). No privacy impact.
- **StatsActivity.java redundant `Uri.parse` removal**: The second `Uri.parse` call in `openUrlInBrowser` was removed (the first parse is now reused for the Intent). No privacy impact — same URL validation, just no double-parse.
- **StabilizationHelper.java comment direction fix**: Corrected a comment that said "below" when referring to `start()` which is actually above `applyTransform()` in source order. No privacy impact.
- **proguard-rules.pro section-3 comment fix**: Rewrote the section-3 comment (same direction-inversion bug as the round-10 section-6 fix). No privacy impact.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged).

## v1.2.1 round-11 (2026.7.14) — 2 user-reported bugs + review-report defects + first-principles optimization

This pass fixes 2 user-reported bugs in the review-mode eval chart and stats page, plus the remaining non-false-positive defects from the round-2 review-report collection, plus a first-principles optimization pass on the changed files. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **Bug #1 fix (review eval chart refresh, `ai-bridge.js`)**: Added a `_refreshEvalTrendChart()` call after the eval cache is updated in `onEngineEval`'s non-stale path. Previously the chart only refreshed on the stale-callback path; the common case "user stays on the analyzed step" left the chart missing the point until the next full render. No privacy impact — purely a UI refresh timing fix.
- **Bug #2 fix (stats page data completeness, `ai-bridge.js` + `ui.js`)**: `openStatsPage` now triggers `reviewAnalyzeAll()` if any review step is uncached, deferring the stats page opening until the batch completes. This ensures the stats page always receives a complete `evals` array. `exitReview` clears the pending-stats flag. No privacy impact — the stats page already had access to the full PGN and move records; only the eval cache completeness changed.
- **`game-logic.js` `pieceCountLE7` typeof guard restored**: Defensive guard against `tablebase.js` load failure. No privacy impact — only affects whether the tablebase probe runs.
- **`ai-bridge.js` `onBestMove` isAIThinking reset on validation failure**: Resets the AI-thinking flag when bestmove parsing fails, preventing a soft-lock. No privacy impact.
- **`ai-bridge.js` `_visualAnnotationsCache` iteration safety**: Switched from `for...of` to `forEach` with a plain-object fallback. No privacy impact — the visual annotations are locally-generated UI aids, not user data.
- **`FileIoHelper.java` `getDefaultPaths` deprecated API fix**: On API 29+, returns `context.getExternalFilesDir(null)` (app-private external storage, always accessible) for the `externalStorage` key instead of the deprecated `Environment.getExternalStorageDirectory()` (which points to inaccessible paths on Android 11+). No privacy impact — these paths are only starting points for the SAF file picker; actual file I/O always uses SAF content URIs.
- **`state-store.js` `_deepClone` nosemgrep comment + Map/Set support**: Added a `// nosemgrep` comment with justification for the `new RegExp(obj.source, obj.flags)` line, plus Map/Set deep-clone branches. No privacy impact — the state store only holds in-memory UI state, never user PII.
- **First-principles optimization**: Race-condition guard for concurrent batch, double-click guard for 📊 button, `exitReview` pending-stats clear, 10-minute safety timeout on the pending-stats flag (prevents permanent lockout if the engine hangs). No privacy impact — purely internal state-management improvements.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged — same-version refinement).

## v1.2.1 round-12 (2026.7.14) — SonarCloud PR #43 bugs + code smells cleanup

This pass fixes the 3 SonarCloud Bugs reported on PR #43 (2 real S3923 "if/else identical" issues + 1 S2757 false-positive refactor) and applies the P0/P1/P2 code-smells cleanup from the `Regalia_v1.2.1_CodeSmells_修复指南.md` guide. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **S3923 if/else identical branches removed (`ui.js`)**: Two `if (_isLandscapeReview) { ... } else { ... }` blocks in `_renderReviewMode` had byte-identical branches (legacy from the v1.1.0 Phase 53 portrait/landscape unification). Removed the conditional, kept one copy. No privacy impact — pure markup-cleanup.
- **S2757 false-positive refactor (`ui.js`)**: Rewrote `_ecoEnabled = !(typeof dlgChess960 !== 'undefined' && dlgChess960)` as `_ecoEnabled = typeof dlgChess960 === 'undefined' || !dlgChess960` (De Morgan's law, identical semantics). No privacy impact — ECO recognition is a local opening-classification lookup, no user data involved.
- **S108 empty catch blocks filled with `console.warn` (~146 sites)**: Empty `catch(e){}` blocks across `ui.js` (93), `ai-bridge.js` (30), `game-logic.js` (19), `tablebase.js` (3), `chess960.js` (1) now log a module-tagged warning. No privacy impact — `console.warn` writes to the WebView JavaScript console (visible only via `adb logcat` or Chrome DevTools); it does NOT transmit any data over the network, does NOT write to persistent storage, and does NOT include user PII (only `e.message` — typically a generic JS error string like "Cannot read property 'x' of undefined"). The catches using `catch(_){}` / `catch(_e){}` (intentionally-unused parameter — a SonarCloud-recognized idiom) were preserved. Catches inside inline HTML event-handler attributes were skipped because expanding them inline would break attribute quoting.
- **S3358 nested ternary operators refactored (`ui.js`, 2 sites)**: The 4-way nested ternary selecting the game-over icon character + style was extracted into two helper functions `_gameOverIconChar()` / `_gameOverIconStyle()` with explicit `if` branches. The 2-way nested ternary computing the mate-score suffix in `formatEval` was refactored to compute `mateSign` once. No privacy impact — pure readability refactors.
- **S3646 duplicate CSS selectors merged (`index.html.tpl`, 2 sites)**: Merged two adjacent `.dlg:not([style*="max-width"])` rules and two adjacent `.review-left .review-board .bgrid` rules. No privacy impact — pure CSS cleanup.
- **S3523 `parseFloat` → `Number.parseFloat` (7 sites)**: Pure ES2015 namespace form. No privacy impact.
- **S1154 `String.fromCharCode` → `String.fromCodePoint` (18 sites)**: All call sites pass ASCII code points < 128 (chess coordinate labels `a`-`h`, SP-ID letters `A`/`a`); behavior is identical. No privacy impact.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged — same-version refinement).

## v1.2.1 round-13 (2026.7.14) — S3776 cognitive complexity: renderInternal God Function refactor

This pass addresses the highest-priority S3776 Cognitive Complexity violation deferred from round-12: the `renderInternal` God Function (CC=122, ~347 lines) is split into 4 named helpers (`_buildRenderHTML`, `_saveScrollState`, `_restoreScrollState`, `_postRenderFinalize`), reducing `renderInternal` to a 23-line thin orchestrator. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **`renderInternal` God Function refactor (`ui.js`)**: The 347-line function is split into 4 named helpers, each with a single responsibility (HTML building, scroll-state snapshot, scroll-state restore, post-render finalization). Behavior is byte-identical to the pre-refactor version; only the structure changed. No privacy impact — the refactor touches only render orchestration; no data is read, written, or transmitted differently.
- **No new globals**: All 4 helpers are module-scoped functions (not exported). They access the same module-level state as the original inline code. No privacy impact.
- **Error handling preserved**: The `try/catch` wrapper around the entire render remains in `renderInternal`. If any helper throws, the error display UI is shown exactly as before. No privacy impact — error messages are displayed locally, never transmitted.
- **Early return preserved**: The `_renderReviewMode` `done=true` early return (which skips scroll-save/innerHTML/scroll-restore to avoid operating on stale DOM) is preserved. No privacy impact.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged — same-version refinement).

## v1.2.1 round-14 (2026.7.14) — S3776 _renderDialogs extraction + S2703 typeof audit

This pass completes the remaining S3776 Cognitive Complexity items deferred from round-13 (`_renderDialogs` CC=71 → ~5) plus the S2703 `typeof` audit deferred from round-12 (53 safe conversions). **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **`_renderDialogs` refactor (`ui.js`)**: The 181-line function (CC=71) is refactored into a 10-line thin dispatcher that delegates to 8 per-dialog helpers (`_renderNewGameDialog`, `_renderChess960Settings`, `_renderClassicOpeningsList`, `_renderResignConfirmDialog`, `_renderAboutDialog`, `_renderImportDialog`, `_renderPromotionDialog`, `_renderSavePGNPromptDialog`). Behavior is byte-identical. No privacy impact — pure structural refactor of render orchestration.
- **S2703 `typeof` audit (53 sites across 4 JS files)**: Converted `typeof <var> === 'undefined'` / `!== 'undefined'` to direct `=== undefined` / `!== undefined` comparison for variables guaranteed to be declared via module-scoped `let`/`var` (`soundOn`, `gameClocks`, `_gameOverStatusKey`, `_reviewEvalCache`, `gameVariant`, `dlgChess960`, and other module-scoped variables). True globals (`crypto`, `AndroidBridge`) correctly preserved with `typeof` to avoid `ReferenceError`. No privacy impact — pure style modernization with identical semantics.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged — same-version refinement).

## v1.2.3 (2026.7.16) — Round 17/18 review fixes + P0 JS error fix + Toast UX

This version addresses a user-reported P0 JS error, Round 17 (Issue #48) and Round 18 (Issue #49) multi-skill review findings, and Issue #47 Toast UX optimization. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **P0 JS error fix (`ui.js`)**: AI difficulty button inline `onclick` refactored into a named global function `setDifficultyLevel(level)`. Previously the inline `onclick` contained `console.warn("[AI] ...")` with double quotes that collided with the HTML attribute delimiter, causing `Uncaught SyntaxError: Unexpected end of input`. No privacy impact — pure UI bug fix; no data transmitted or stored.
- **Round 17 P1 — cloneS Chess960 fields (`game-logic.js`)**: `cloneS()` now copies `chess960` and `spid` fields. No privacy impact — pure correctness fix for Chess960 state cloning.
- **Round 17 P1 — sendSetOptionAndWait Pattern caching (`StockfishNative.java`)**: Pre-compiled `NEWLINE_PATTERN` + `stripNewlines()` helper. No privacy impact — performance optimization only.
- **Round 17 P1 — saveEvalCacheSync .tmp leak (`StockfishNative.java`)**: `finally` block guarantees `.tmp` cleanup. The eval cache is a local-only file in `context.getFilesDir()` containing engine evaluation data (no PII). The fix prevents stale `.tmp` file accumulation; no data leaves the device.
- **Round 17 P1 — C++ standard mismatch (`CMakeLists.txt`)**: `cxx_std_17` → `cxx_std_20` to match `build.gradle`. No privacy impact — build config alignment.
- **Round 18 i18n P1 — aria-label, game-over detection, html lang (`ui.js`, `game-logic.js`)**: Three i18n fixes for accessibility and language consistency. No privacy impact — UI text/accessibility only.
- **Round 18 P1 — analyze-all setoption redundancy (`StockfishNative.java`, `ui.js`)**: Added `engineEvalDeepBeginBatch()` / `engineEvalDeepEndBatch()` Java methods to skip redundant UCI setoption calls during batch analysis. No privacy impact — performance optimization; engine communication is local-only.
- **Issue #47 Toast UX (`ai-bridge.js`, `ui.js`, `game-logic.js`)**: Path 3 staged intent+progress toasts; Path 4 completion toast before deferred stats open. New i18n key `analysis_complete_opening_stats`. No privacy impact — Toast text is rendered locally.
- **Round 17 P2 — StabilizationHelper, engine_jni.cpp errno, stopAndWaitForBestmove health**: Three robustness fixes. No privacy impact — internal diagnostics and recovery.
- **False positives excluded**: Round 17 P1-4 (EngineConfigManager — already deleted), P1-5 (StatsActivity JS Bridge — onDestroy already cleans up), P2-1 (UciProtocolHandler — already deleted), P2-2 (RootDetector deprecated API — informational only). Round 18 i18n-P2-1 (`placeholder="0-959"` — numeric), A-P1-1/2/3/4 (God Class refactors — deferred).

Version: `versionCode=123`, `versionName="1.2.3"` (version bump from v1.2.2).

## v1.2.3 optimization pass (2026.7.16) — first-principles line-by-line review

A line-by-line first-principles review of every source file was performed after the Round 17/18 fix pass. **No versionCode bump.** **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal code-quality, documentation-accuracy, and redundancy-cleanup improvements with zero privacy impact:

- **Stale API version comments corrected** (`StockfishNative.java`, `ChessWebViewClient.java`, `network_security_config.xml`): "API 21" references updated to "API 23" to match the actual `minSdk 23`. Documentation-only; no code behavior change. No privacy impact.
- **Version string comments updated** (`MainActivity.java`, `ChessWebViewClient.java`): Example version references updated from "v1.2.1"/"v1.2.2" to "v1.2.3". No privacy impact — comments only.
- **`EngineConfigHelper.setGameDifficulty` callback**: Converted raw string-concatenation `postJsCallback` to the structured `postJsCallback(eventName, args...)` overload. No privacy impact — the callback only passes a boolean and an int (limitElo, elo) to JS; no PII, no network, no storage.
- **`StatsActivity` JS bridge comment**: Added a clarifying comment documenting why the anonymous JS bridge is safe (onDestroy cleanup + Java GC). No privacy impact — comment only.
- **`gradle.properties`**: Removed redundant `android.enableR8.fullMode=true` (default in AGP 8.x). No privacy impact — build config only.
- **HTML manuals renamed + wireframe version badge fixed**: `Regalia-v1.2.2-manual-{zh,en}.html` → `Regalia-v1.2.3-manual-{zh,en}.html`; header-bar wireframe badge updated from `v1.0.7` to `v1.2.3` to match the actual app rendering. No privacy impact — documentation only.
- **README.md directory tree accuracy fixes**: `strings.xml` comment "v1.2.1" → "v1.2.3"; `build.gradle` comment "versionCode=121" → "versionCode=123"; manual filename references updated. No privacy impact — documentation only.

Version: `versionCode=123`, `versionName="1.2.3"` (unchanged — optimization pass, no version bump).

## v1.2.2 (2026.7.14) — Comprehensive audit-report non-false-positive fix + version bump

This version is based on the uploaded comprehensive audit-report collection (`Regalia_v1.2.1_全技能审查报告.zip`). After rigorous code-level verification, 7 of the audit's findings were confirmed as false positives (based on stale code from deleted files or already-fixed issues), and 1 real defect was fixed. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **FEN parsing length limit (`tablebase.js`)**: `fenToState()` now rejects FEN strings longer than 200 characters (standard FEN ≤87 chars). This is a DoS-prevention hardening measure — a pathologically long FEN string could previously cause unnecessary string processing before validation rejected it. No privacy impact — FEN strings are chess position notation with no PII; the length limit simply fails faster on invalid input.
- **Version bump (v1.2.1→v1.2.2)**: 11 version-number locations updated (version.properties, build.gradle, strings.xml, ChessWebViewClient.java, game-logic.js, index.html.tpl, ui.js 3 places, HTML manuals). No privacy impact — version numbers are public information.
- **Audit-report false positives confirmed (no action taken)**: RED-1 (getStatsPayload XSS — stats.html already escapes via `_escFEN`), RED-2 (javascript: protocol — already blocked), RED-3 (i18n XSS — static strings + double escaping), YELLOW-2 (sendToEngine — already has UCI whitelist), YELLOW-3 (allowBackup — already false), YELLOW-5 (ProGuard — MessageBus deleted), P0 #4-5 (empty catches — round-16 fixed), P1 #12 (HapticHelper — round-10 deleted).

Version: `versionCode=122`, `versionName="1.2.2"` (version bump from v1.2.1).

## v1.2.1 round-16 (2026.7.14) — User-reported UX clarity + audit-report non-false-positive defect fixes

This round addresses two user-reported UX-clarity issues plus 3 non-false-positive defects from the uploaded audit report. **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **📊 Toast clarity in review mode (`ai-bridge.js`, `game-logic.js`)**: When the user clicks 📊 in review mode and a background analysis batch is needed, the Toast now appends "分析完成后将进入统计页面 / Statistics will open after analysis completes" so the user knows to wait. Two new i18n keys (`stats_will_open_after_analysis`, `analysis_timed_out_retry`) added to `game-logic.js`. No privacy impact — Toast text is rendered locally; no data is transmitted or stored.
- **Visual annotation wording fix (`stats.html`)**: The description for green arrows (应将路径) was reordered from "王避将或吃将军棋子" to "吃将军棋子或王避将" to eliminate a parsing ambiguity. Documentation-only change. No privacy impact.
- **Empty `catch(e){}` blocks filled (`game-logic.js`, `ui.js`)**: The `_ecoRestoreFocus` catch and the inline `AndroidBridge.syncGameDifficulty` catch now log `console.warn(...)`. No privacy impact — `console.warn` writes to the WebView JavaScript console (visible only via `adb logcat` or Chrome DevTools); it does NOT transmit any data over the network, does NOT write to persistent storage, and does NOT include user PII.
- **Chess960 SPID `Math.random()` fallback removed (`ui.js`)**: The unreachable `typeof secureRandomInt==='function'?...:Math.floor(Math.random()*960)` is simplified to `secureRandomInt(960)`. `secureRandomInt` uses `crypto.getRandomValues()` (already used elsewhere) — this change actually *improves* the cryptographic strength of the SPID generation by removing the insecure fallback. No privacy impact.
- **SECURITY-AUDIT comments added (`ui.js`)**: Two comments added above `_createImpulse()` and `_getNoise()` explaining that `Math.random()` is intentionally used for audio noise synthesis. No privacy impact — comments only.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged — same-version refinement).

## v1.2.1 round-15 (2026.7.14) — Final perfection: S3776 _renderReviewMode partial extraction + stats.html S108 + comprehensive PDF-guided audit

This is the **final perfection round** — a comprehensive, first-principles audit of every source file guided by the three uploaded PDFs (AI Code Generation Defect Prevention Guide, Android WebView Development Guide, SonarCloud Perfect Review Guide). **No new permissions, no new data collection, no new network access, no changes to data flow or storage.** All changes are internal to the app and have zero privacy impact:

- **`_renderReviewMode` partial extraction (`ui.js`)**: Extracted 3 self-contained helpers (`_buildRvFileLabels`, `_buildRvRankLabels`, `_prepareRvVisualAnnotations`) from the 612-line function, reducing it to 561 lines. Byte-identical behavior. No privacy impact — pure structural refactor of review-board rendering.
- **stats.html S108 empty catch blocks (6 sites)**: Added `console.warn('[Stats]', e.message)` to 6 empty `catch(e){}` blocks in `stats.html`. No privacy impact — `console.warn` writes to the WebView JavaScript console (visible only via `adb logcat` or Chrome DevTools); it does NOT transmit any data over the network, does NOT write to persistent storage, and does NOT include user PII.
- **PDF-guided audit verified**: WebView security settings (`setAllowFileAccess(false)`, `setAllowFileAccessFromFileURLs(false)`, `setAllowUniversalAccessFromFileURLs(false)`) confirmed correct. `@JavascriptInterface` annotation on all exposed methods. `onDestroy` cleanup complete. Debug mode never enabled (system default = disabled). TLS pinning implemented. No hardcoded secrets. PGN/FEN input escaped for XSS prevention. No privacy impact — all findings confirm existing security posture is correct.

Version: `versionCode=121`, `versionName="1.2.1"` (unchanged — same-version refinement).

## Contact

For questions about this privacy policy, please open an issue on the GitHub repository.

---
*AI-GEN*
