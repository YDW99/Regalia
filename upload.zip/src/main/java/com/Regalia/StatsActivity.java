// StatsActivity.java — Fullscreen WebView activity for the 📊统计 stats page.
// AI-GEN: AI assisted
// This code was AI-assisted and has been reviewed for GPL v3 compliance.

//
// Copyright (C) 2026 Regalia
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
//
// The stats.html asset contains PGN parsing logic derived from DroidFish
// (GameTree/PgnToken/PgnScanner, Copyright (C) Peter Österlund, GPL v3).
// v1.0.8 PHASE 37/49: Although this Java file is original Regalia code, it is
//   classified as GPL v3 (not AGPL v3) to match the license of the stats.html
//   asset it exclusively hosts — the two form a single inseparable unit
//   (StatsActivity loads stats.html and the two communicate via
//   @JavascriptInterface). Keeping them under the same license avoids
//   dual-license confusion for redistributors. The GPL v3 boilerplate above
//   is therefore authoritative; earlier comments mentioning "AGPL v3" were
//   stale and have been removed.

package com.Regalia;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 * v1.0.2 NEW FEATURE: Fullscreen WebView activity that displays the 📊统计
 * (statistics) page. The page is loaded from assets/stats.html and receives
 * the game PGN + eval data via an Intent extra.
 *
 * The activity handles:
 *   - Android back button: finish() (return to main game)
 *   - 💾HTML export: SAF picker → write HTML to user-chosen file
 *   - 🗃️导入 (Paste PGN / Select PGN file): handled entirely inside stats.html
 *       and StatsActivity — the SAF picker opens directly from this activity
 *       and the file content is passed back via onStatsPGNFileRead(content).
 *       No round-trip through MainActivity.
 *   - 🗂️复盘: finish() and notify main WebView to enter review mode
 *   - 返回对局: finish()
 *
 * License: GPL v3 (classified to match the stats.html asset it hosts, which
 * contains DroidFish-derived PGN parsing logic).
 */
public class StatsActivity extends Activity {

    private static final String TAG = "Regalia/StatsActivity";
    private static final int REQUEST_CODE_EXPORT_HTML = 2001;
    private static final int REQUEST_CODE_IMPORT_PGN = 2002;
    private WebView webView;
    // v1.2.1 round-10 (review-E P2): volatile — written in onCreate (main thread)
    //   and read from @JavascriptInterface getStatsPayload() (JS binder thread).
    //   Previously relied on the implicit happens-before from webView.loadUrl,
    //   which is correct but fragile. volatile makes the visibility guarantee
    //   explicit and tooling-friendly.
    private volatile String statsPayload;
    // v1.0.8 PHASE 49: volatile — written by the WebView's JS thread (via
    //   @JavascriptInterface) inside evaluate() and cleared inside
    //   exportStats(), and read on the main thread (exportStats via
    //   runOnUiThread). Without volatile the main thread could see a stale
    //   null and skip the export, or see a stale non-null and export twice.
    private volatile String pendingExportHTML;
    // v1.2.3 round-30 (redundant): lazily-initialized HapticManager for the
    //   stats page's performHaptic @JavascriptInterface. Volatile for the
    //   same cross-thread reason as pendingExportHTML.
    private volatile HapticManager _statsHapticManager = null;
    // v1.0.4 Rev28: The PGN text imported on the stats page (via 🗃️ Paste PGN or
    // 📂 Select PGN File). When the user returns to the main activity, if this is
    // non-null, MainActivity prompts "🗃️ Import PGN to game?" Yes/No/Cancel.
    // Cleared to null when MainActivity reads it (one-shot consumption).
    // Static so MainActivity can access it without holding a StatsActivity ref.
    public static volatile String importedPGNOnStats = null;
    // v1.2.3 round-44 (E4): BACK 键兜底状态。onKeyDown 把返回决策交给 JS
    //   （handleStatsBackPress/returnToGame），若 JS 异常或未定义则 Activity
    //   永远不会 finish，用户以为 BACK 失灵。JS 正常关闭路径会经桥接方法
    //   closeStatsPage()（关闭）或 ackStatsBackHandled()（留在本页，
    //   v1.2.3 round-46 PR53 CR#26 新增）置位 backCloseHandled，250ms 超时
    //   兜底检测到已置位即放弃 finish()。
    private final java.util.concurrent.atomic.AtomicBoolean backCloseHandled =
            new java.util.concurrent.atomic.AtomicBoolean(false);
    private android.os.Handler backFallbackHandler;
    // v1.2.3 round-48 (BUG-2): manifest opts into
    //   android:enableOnBackInvokedCallback="true", which suppresses
    //   KeyEvent.KEYCODE_BACK dispatch on API 33+ — without a registered
    //   callback the system would just finish() and bypass
    //   handleStatsBackPress()/returnToGame() (import interceptor, dialog
    //   closing, 250ms fallback). Platform API, no androidx dependency.
    private android.window.OnBackInvokedCallback _backInvokedCallback = null;

    /**
     * v1.2.3 round-48 (BUG-2): register the platform OnBackInvokedCallback on
     *   API 33+; the callback reuses handleBackKeyPress() (the exact logic of
     *   the onKeyDown(KEYCODE_BACK) branch) and finishes when it declines.
     */
    private void registerBackInvokedCallback() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            try {
                _backInvokedCallback = new android.window.OnBackInvokedCallback() {
                    @Override
                    public void onBackInvoked() {
                        if (!handleBackKeyPress()) {
                            finish();
                        }
                    }
                };
                getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                        android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                        _backInvokedCallback);
            } catch (Throwable e) {
                Log.w(TAG, "OnBackInvokedCallback registration failed", e);
                _backInvokedCallback = null;
            }
        }
    }

    /**
     * v1.2.3 round-48 (BUG-2): core BACK handling extracted from onKeyDown so
     *   the API 33+ OnBackInvokedCallback reuses it verbatim.
     *   Returns true when the press was handed to the JS side; false means the
     *   caller must apply the system default (finish).
     */
    private boolean handleBackKeyPress() {
        // Handle Android back button.
        // v1.0.4 Rev28: Delegate to the JS-side returnToGame() so the
        // "🗃️ Import PGN to game?" interceptor can fire when a PGN was
        // imported on the stats page. returnToGame() either closes the
        // activity (no import) or shows the Yes/No/Cancel dialog (Cancel =
        // stay on stats page). If the import-back dialog is already visible,
        // back button = Cancel (dismiss dialog, stay on stats page).
        // v1.0.7 UI: Route through the unified handleStatsBackPress() which
        // also closes export/import dialogs created via DOM appendChild
        // (previously these were orphaned by the back button — only the
        // import-back Yes/No/Cancel was handled).
        if (webView != null) {
            // v1.2.3 round-44 (E4): 先复位标志，再发 JS；250ms 后若 JS 未
            //   经 closeStatsPage()/ackStatsBackHandled() 置位（JS 异常/函数未定义），兜底
            //   finish()。正常关闭路径会置位 backCloseHandled，兜底
            //   Runnable 检测到后放弃 —— 超时兜底可被正常 closeStatsPage
            //   取消。
            backCloseHandled.set(false);
            webView.evaluateJavascript(
                "if(typeof handleStatsBackPress==='function'){handleStatsBackPress();}" +
                "else if(typeof _statsImportBackDialogVisible!=='undefined'&&_statsImportBackDialogVisible){" +
                "  _statsImportBackDismiss();" +
                "} else if(typeof returnToGame==='function'){" +
                "  returnToGame();" +
                "}",
                null);
            if (backFallbackHandler != null) {
                backFallbackHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (!backCloseHandled.get() && !isFinishing() && !isDestroyed()) {
                                Log.w(TAG, "BACK fallback: JS did not close stats page within 250ms — finishing");
                                finish();
                            }
                        }
                    }, 250);
            }
            return true;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // v1.0.5 Rev55: Fullscreen immersive mode — match MainActivity's
        // Android-15-aware approach. Previously used deprecated FLAG_FULLSCREEN
        // which conflicts with Edge-to-Edge enforcement on API 35+ (causes
        // black screen / offset viewport on HyperOS 3).
        try {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
        } catch (Throwable e) {
            Log.w(TAG, "requestWindowFeature failed", e);
        }
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) {
            // FLAG_FULLSCREEN is valid on API 23-29 only; on API 30+ it
            // conflicts with Edge-to-Edge.
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }

        // Get the stats payload from the Intent
        statsPayload = getIntent().getStringExtra("statsPayload");
        if (statsPayload == null || statsPayload.isEmpty()) {
            Log.e(TAG, "No stats payload in Intent");
            finish();
            return;
        }

        // Create WebView
        webView = new WebView(this);
        // v1.0.5 Rev55: Match MainActivity's background color to avoid white flash.
        webView.setBackgroundColor(android.graphics.Color.parseColor("#1a0a0a"));
        // v1.0.5 Rev55: tapjacking defense (match MainActivity).
        webView.setFilterTouchesWhenObscured(true);
        setContentView(webView);
        backFallbackHandler = new android.os.Handler(android.os.Looper.getMainLooper()); // v1.2.3 round-44 (E4)
        // v1.2.3 round-48 (BUG-2): API 33+ back events go to the dispatcher,
        //   not onKeyDown — register the callback now that webView/handler exist.
        registerBackInvokedCallback();

        // v1.0.5 Rev55: WebView security configuration — defense-in-depth parity
        // with MainActivity. The stats page also loads only local asset content,
        // but the security defaults should be identical to prevent a weaker
        // attack surface on the stats activity. Without these flags, a
        // compromised WebView (or a future code change that loads remote content)
        // could access file:// or content:// URIs.
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        // SECURITY: Disable all file/content access (same as MainActivity).
        // The stats page loads only from file:///android_asset/stats.html and
        // never needs file:// or content:// access — all PGN file I/O goes
        // through the JS bridge via SAF (Storage Access Framework).
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        // SECURITY: Block mixed content (no http subresource loads over https).
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setTextZoom(100);

        // Register a minimal JS bridge for the stats page.
        // v1.2.3 note (Round 17 P1-5 false-positive clarification): The
        //   anonymous Object captures the outer StatsActivity, creating a
        //   cycle (Activity → webView → bridge → Activity). This is safe
        //   because: (1) StatsActivity.onDestroy() calls
        //   removeJavascriptInterface("AndroidBridge") + webView.destroy()
        //   + webView = null, which breaks the chain; (2) Java's tracing GC
        //   handles cycles when no node outlives the Activity; (3) the
        //   WebView's lifecycle is owned by the Activity. So this is not a
        //   real leak — it would only leak if onDestroy were skipped, which
        //   Android guarantees for Activity lifecycle.
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public String getStatsPayload() {
                return statsPayload;
            }

            // v1.0.8 PHASE 22 (bug fix): Expose system dark-mode state to stats.html.
            // Same implementation as StockfishNative.isSystemDarkMode() — reads
            // UiModeManager to reliably detect system dark/light mode on all
            // devices including Xiaomi HyperOS 3 where prefers-color-scheme is
            // unreliable. stats.html init() calls this to set data-theme attribute.
            @JavascriptInterface
            public boolean isSystemDarkMode() {
                try {
                    android.app.UiModeManager umm = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE);
                    if (umm == null) return true;
                    int mode = umm.getNightMode();
                    if (mode == android.app.UiModeManager.MODE_NIGHT_NO) return false;
                    if (mode == android.app.UiModeManager.MODE_NIGHT_YES) return true;
                    int curMode = getResources().getConfiguration().uiMode
                            & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
                    return curMode == android.content.res.Configuration.UI_MODE_NIGHT_YES;
                } catch (Throwable e) {
                    return true;
                }
            }

            @JavascriptInterface
            public void closeStatsPage() {
                // v1.2.3 round-44 (E4): 置位标志以取消 BACK 键的 250ms 超时兜底。
                backCloseHandled.set(true);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                });
            }

            // v1.2.3 round-46 (PR53 CR#26): BACK 键的「已处理但留在本页」回执。
            //   handleStatsBackPress() 有多条合法分支只关对话框/取消导入而
            //   不关闭页面（不调用 closeStatsPage）——原设计里这些分支不会
            //   置位 backCloseHandled，250ms 兜底会误判 JS 无响应并 finish()，
            //   把按「取消」的用户踢出统计页。JS 在每条消费分支末尾必须调用
            //   本方法回执（置位但不 finish）。
            @JavascriptInterface
            public void ackStatsBackHandled() {
                backCloseHandled.set(true);
            }

            // v1.0.2: Haptic feedback for stats page buttons.
            // v1.0.2 FIX: Respect the user's haptic preference (read from the
            // same "RegaliaEngine" prefs that StockfishNative.saveLangPref and
            // the haptic toggle use). Previously this always vibrated, ignoring
            // both the in-app haptic setting and the system haptic setting —
            // users who disabled haptic in main app settings still felt
            // vibration from stats page buttons. Also upgraded to VibrationEffect
            // on API 26+ to match StockfishNative's pattern (deprecated
            // vibrate(long) on newer APIs).
            @JavascriptInterface
            public void performHaptic(String type) {
                // v1.2.3 round-30 (redundant): delegate to HapticManager.
                //   Previously this method reimplemented the haptic-enabled
                //   check + VibrationEffect fallback chain inline, duplicating
                //   HapticManager's logic. The duplication created two sources
                //   of truth that could diverge (e.g. round-30's 5s setting
                //   cache would have needed to be applied in both places).
                //   The stats page only uses BUTTON_PRESS-style feedback, so
                //   the single 20ms pulse is sufficient. We delegate to
                //   HapticManager.performHaptic, which handles the gating +
                //   vibrator lookup + API-level dispatch centrally.
                try {
                    // v1.2.3 round-44 (E5): 懒初始化改 DCL。performHaptic 从 JS
                    //   binder 线程调用，旧的无锁 check-then-act 在快速连点时可
                    //   构造两个 HapticManager（后者覆盖前者，功能无害但浪费，
                    //   且字段发布无 happens-before 保证）。字段已是 volatile，
                    //   此处补 synchronized 双检。
                    HapticManager hm = _statsHapticManager;
                    if (hm == null) {
                        synchronized (StatsActivity.this) {
                            hm = _statsHapticManager;
                            if (hm == null) {
                                hm = new HapticManager(
                                    StatsActivity.this,
                                    getSharedPreferences("RegaliaEngine", MODE_PRIVATE),
                                    new android.os.Handler(android.os.Looper.getMainLooper())
                                );
                                _statsHapticManager = hm;
                            }
                        }
                    }
                    hm.performHaptic(type);
                } catch (Throwable e) {
                    Log.w(TAG, "performHaptic failed", e);
                }
            }

            @JavascriptInterface
            public void exportStatsHTML(String html) {
                pendingExportHTML = html;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                            intent.addCategory(Intent.CATEGORY_OPENABLE);
                            intent.setType("text/html");
                            intent.putExtra(Intent.EXTRA_TITLE, "Regalia_stats.html");
                            startActivityForResult(intent, REQUEST_CODE_EXPORT_HTML);
                        } catch (Throwable e) {
                            Log.e(TAG, "exportStatsHTML picker failed", e);
                            pendingExportHTML = null;
                        }
                    }
                });
            }

            // v1.0.2 FIX: Direct SAF file picker for PGN import from stats page.
            // Previously, the stats import dialog's "Select PGN File" button called
            // statsRequestImport() which finished the stats activity and bounced the
            // user back to the main activity before opening the picker — jarring UX.
            // Now we open ACTION_OPEN_DOCUMENT directly from StatsActivity, read the
            // file in onActivityResult, and pass the content back to stats.html via
            // the onStatsPGNFileRead(content) JS callback so the stats page can
            // re-render with the imported PGN without leaving the stats view.
            //
            // v1.0.2 CLEANUP: The old statsRequestImport() bridge method, the
            // MainActivity.pendingStatsImportRequest flag, and the main-WebView
            // onStatsRequestImport() handler have all been removed — the entire
            // import flow now stays inside StatsActivity, eliminating the round-trip.
            @JavascriptInterface
            public void statsSelectPGNFile() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                            intent.addCategory(Intent.CATEGORY_OPENABLE);
                            intent.setType("*/*");
                            intent.putExtra(Intent.EXTRA_MIME_TYPES,
                                    new String[]{"application/x-chess-pgn", "text/plain", "application/octet-stream"});
                            startActivityForResult(intent, REQUEST_CODE_IMPORT_PGN);
                        } catch (Throwable e) {
                            Log.e(TAG, "statsSelectPGNFile picker failed", e);
                            evalJs("if(typeof onStatsPGNFileRead==='function')onStatsPGNFileRead('')");
                        }
                    }
                });
            }

            @JavascriptInterface
            public void statsRequestReview() {
                // Close stats page and notify main WebView to enter review mode
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // round-47 (S2696 kept): 跨 Activity 一次性请求标记（此处写、MainActivity.onResume 消费），有意写 static 字段。
                        MainActivity.pendingStatsReviewRequest = true;
                        finish();
                    }
                });
            }

            // v1.0.3: Load an asset file as base64 — used for GPL v3 logo in export dialog
            @JavascriptInterface
            public String loadAssetAsBase64(String assetPath) {
                // v1.2.3 round-30 (robustness): path-traversal check, mirroring
                //   FileIoHelper.loadAssetAsBase64 (line 481). AssetManager.open
                //   itself rejects ".." traversal, but the explicit guard is
                //   defense-in-depth and matches the parallel implementation.
                if (assetPath == null || assetPath.isEmpty() || assetPath.contains("..")) {
                    Log.w(TAG, "loadAssetAsBase64: blocked path traversal: " + assetPath);
                    return null;
                }
                // v1.0.5 Rev61: try-with-resources guarantees InputStream is closed
                // even if baos.write throws (e.g. OOM on a huge asset).
                try (java.io.InputStream is = getAssets().open(assetPath)) {
                    java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                    byte[] buffer = new byte[4096];
                    int len;
                    while ((len = is.read(buffer)) != -1) {
                        baos.write(buffer, 0, len);
                    }
                    return android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP);
                } catch (Throwable e) {
                    Log.w(TAG, "loadAssetAsBase64 failed: " + assetPath, e);
                    return null;
                }
            }

            // v1.0.4 Rev28: Record the PGN text imported on the stats page (via
            // 🗃️ Paste PGN or 📂 Select PGN File). Called from stats.html's
            // _statsPastePGN() and onStatsPGNFileRead() handlers. The imported
            // PGN is stashed in the static importedPGNOnStats field; when the
            // user returns to MainActivity, MainActivity.onResume() checks this
            // field and prompts "🗃️ Import PGN to game?" if non-null.
            // One-shot: MainActivity clears the field after reading it.
            @JavascriptInterface
            public void setImportedPGN(String pgnText) {
                // round-47 (S2696 kept): importedPGNOnStats 为跨 Activity 静态握手字段（此处 stash、MainActivity.onResume 读取后清零），有意写 static 字段。
                importedPGNOnStats = pgnText;
                Log.i(TAG, "Recorded imported PGN on stats page (" +
                        (pgnText != null ? pgnText.length() : 0) + " chars)");
            }

            // v1.0.4 Round-5 Rev27: Open an external http(s) URL in the system default
            // browser. Called from JS when the user taps any hyperlink in stats.html
            // (e.g. license links). Same security model as StockfishNative.openUrlInBrowser:
            // only http(s) URLs are allowed; all other schemes are silently rejected.
            @JavascriptInterface
            public void openUrlInBrowser(String url) {
                if (url == null) return;
                String trimmed = url.trim();
                // v1.2.1 round-10 (review-E P2): case-insensitive scheme check
                //   (mirrors StockfishNative._isHttpUrl). RFC 3986 §3.1: scheme
                //   is case-insensitive — accept "HTTP://...", "Https://...", etc.
                // v1.2.1 round-10 regression: reuse `parsed` for the Intent instead
                //   of re-parsing (was a redundant second Uri.parse call).
                Uri parsed = Uri.parse(trimmed);
                String scheme = parsed.getScheme();
                if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
                    Log.w(TAG, "openUrlInBrowser rejected non-http(s) URL: " + trimmed);
                    return;
                }
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, parsed);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    Log.i(TAG, "Opened external URL in browser: " + trimmed);
                } catch (Throwable e) {
                    Log.e(TAG, "openUrlInBrowser failed for: " + trimmed, e);
                }
            }
        }, "AndroidBridge");

        // Set WebViewClient to load stats.html from assets.
        // v1.0.4 Rev27: External http(s) URLs are now opened in the system browser
        // (defense-in-depth alongside the JS-side openUrlInBrowser bridge).
        // v1.1.2 PHASE 71 (robustness): Add the deprecated shouldOverrideUrlLoading
        //   overload (WebView, String) so that on API 23 (minSdk=23) external
        //   http(s) URLs are also redirected to the system browser. On those API
        //   levels, only the deprecated overload fires; the new
        //   WebResourceRequest-based overload is API 24+ only. Without this, a
        //   stats-page navigation to an external URL would load INTO the WebView
        //   (bypassing the system browser) on older devices. Also added
        //   onRenderProcessGone so that a render-process crash on the stats page
        //   finishes the activity instead of leaving a blank, unresponsive WebView
        //   (mirrors ChessWebViewClient's handling for the main chess board).
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = (request != null && request.getUrl() != null) ? request.getUrl().toString() : "";
                return _handleUrlOverride(url);
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return _handleUrlOverride(url != null ? url : "");
            }

            @Override
            public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                Log.e(TAG, "Stats WebView render process gone: crashed=" +
                        (detail != null && detail.didCrash()));
                try {
                    if (view != null) {
                        view.destroy();
                    }
                } catch (Throwable ignored) {}
                finish();
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        // Load the stats.html asset
        webView.loadUrl("file:///android_asset/stats.html");

        // v1.0.5 Rev55: Apply immersive mode (hide system bars) — match MainActivity.
        // The user expects the stats page to be fully immersive too.
        _applyImmersiveMode();

        Log.i(TAG, "StatsActivity created, loading stats.html");
    }

    /**
     * v1.1.2 PHASE 71: Shared URL-override logic for both the API 24+
     * {@link WebViewClient#shouldOverrideUrlLoading(WebView, WebResourceRequest)}
     * and the deprecated {@link WebViewClient#shouldOverrideUrlLoading(WebView, String)}
     * (which is the only one that fires on API 23). Returns {@code true} to
     * block the WebView from loading the URL ourselves; {@code false} to let
     * the WebView proceed (only for our own asset:// URLs).
     */
    private boolean _handleUrlOverride(String url) {
        if (url == null || url.isEmpty()) {
            return true; // Block empty URLs
        }
        if (url.startsWith("file:///android_asset/")) {
            return false; // Allow loading our own bundled assets
        }
        // v1.2.1 round-10 (review-E P2): case-insensitive scheme check.
        //   Previously case-sensitive startsWith rejected "HTTP://..." URLs.
        Uri parsed = Uri.parse(url);
        String scheme = parsed.getScheme();
        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, parsed);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Throwable e) {
                Log.w(TAG, "Failed to open external URL from stats WebView: " + url, e);
            }
            return true;
        }
        return true; // Block all other URL navigation (data:, javascript:, intent:, etc.)
    }

    /**
     * v1.0.5 Rev55: Apply immersive mode to hide system bars.
     * Mirrors MainActivity.enableImmersiveMode() — uses platform
     * WindowInsetsController on API 30+, legacy flags on API 23-29.
     */
    @android.annotation.SuppressLint("NewApi")
    private void _applyImmersiveMode() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 35) {
                // Android 15+: Edge-to-Edge enforced, just hide system bars.
                try {
                    getWindow().getInsetsController().hide(android.view.WindowInsets.Type.systemBars());
                    getWindow().getInsetsController().setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                } catch (Throwable e) {
                    Log.w(TAG, "Android 15+ immersive mode failed", e);
                    _applyLegacyImmersive();
                }
                return;
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                try {
                    getWindow().setDecorFitsSystemWindows(false);
                    getWindow().getInsetsController().hide(android.view.WindowInsets.Type.systemBars());
                    getWindow().getInsetsController().setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                } catch (Throwable e) {
                    Log.w(TAG, "API 30-34 immersive mode failed", e);
                    _applyLegacyImmersive();
                }
                return;
            }
            _applyLegacyImmersive();
        } catch (Throwable e) {
            Log.w(TAG, "_applyImmersiveMode failed", e);
        }
    }

    private void _applyLegacyImmersive() {
        try {
            View decorView = getWindow().getDecorView();
            if (decorView != null) {
                decorView.setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                );
            }
        } catch (Throwable e) {
            Log.w(TAG, "_applyLegacyImmersive failed", e);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) _applyImmersiveMode();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_EXPORT_HTML) {
            String html = pendingExportHTML;
            pendingExportHTML = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || html == null) {
                evalJs("if(typeof onStatsHTMLExported==='function')onStatsHTMLExported(false,'')");
                return;
            }
            try {
                Uri uri = data.getData();
                // v1.2.1 round-9: openOutputStream can return null per Android
                //   docs (e.g. if the URI provider is unavailable or the file
                //   is not writable). Without this check, the OutputStreamWriter
                //   constructor would throw NPE, which is caught by the outer
                //   catch but produces a confusing "Stats HTML export failed"
                //   message instead of the actual root cause.
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) {
                    throw new IOException("openOutputStream returned null for " + uri);
                }
                try (OutputStream autoClose = os;
                     OutputStreamWriter writer = new OutputStreamWriter(autoClose, "UTF-8")) {
                    writer.write(html);
                    writer.flush();
                }
                String displayName = "Regalia_stats.html";
                try {
                    android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                    if (cursor != null) {
                        try {
                            int nameIdx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                            if (nameIdx >= 0 && cursor.moveToFirst()) {
                                displayName = cursor.getString(nameIdx);
                            }
                        } finally { cursor.close(); }
                    }
                } catch (Throwable ignored) {}
                // v1.0.2 FIX: JSON-encode displayName for safe JS string passing.
                // Previously used displayName.replace("'", "\\'") which is
                // insufficient — a filename containing a backslash followed by
                // a quote, or a literal newline, would break the JS string
                // literal. JSON encoding handles all special characters safely.
                String jsonName;
                try {
                    jsonName = new org.json.JSONObject().put("name", displayName).toString();
                } catch (Throwable je) {
                    jsonName = "{\"name\":\"Regalia_stats.html\"}";
                }
                evalJs("if(typeof onStatsHTMLExported==='function'){try{var _d=" + jsonName + ";onStatsHTMLExported(true,_d.name);}catch(e){console.error('stats HTML export callback error:',e);}}");
            } catch (Throwable e) {
                Log.e(TAG, "Stats HTML export failed", e);
                evalJs("if(typeof onStatsHTMLExported==='function')onStatsHTMLExported(false,'')");
            }
        } else if (requestCode == REQUEST_CODE_IMPORT_PGN) {
            // v1.0.2 FIX: Read PGN file content and pass back to stats.html
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                evalJs("if(typeof onStatsPGNFileRead==='function')onStatsPGNFileRead('')");
                return;
            }
            try {
                Uri uri = data.getData();
                // v1.2.1: 不再 takePersistableUriPermission —— 一次性读取不需要持久授权，
                //   且会无谓占用 SAF 512 上限。transient FLAG_GRANT_READ_URI_PERMISSION
                //   from ACTION_OPEN_DOCUMENT 已足够读取本次内容。
                StringBuilder sb = new StringBuilder();
                // v1.2.3 round-13 (P1): openInputStream may return null (e.g.
                //   provider unavailable, file deleted between picker and read).
                //   Mirrors SafPickerHelper.readTextFromUri and the EXPORT path's
                //   openOutputStream null-check at line ~547.
                InputStream rawIs = getContentResolver().openInputStream(uri);
                if (rawIs == null) {
                    throw new IOException("openInputStream returned null for " + uri);
                }
                try (InputStream is = rawIs;
                     BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
                    String line;
                    int lineCount = 0;
                    final int MAX_LINES = 5000; // Match StockfishNative's limit
                    // v1.0.8 PHASE 32 ROBUSTNESS: track truncation and append a
                    //   warning comment (matching StockfishNative's behavior).
                    boolean truncated = false;
                    while ((line = reader.readLine()) != null) {
                        if (lineCount >= MAX_LINES) { truncated = true; break; }
                        sb.append(line).append("\n");
                        lineCount++;
                    }
                    if (truncated) {
                        sb.append("\n{ Warning: file truncated at ").append(MAX_LINES)
                          .append(" lines by Regalia import guard }\n");
                    }
                }
                String content = sb.toString();
                // Sanitize control characters (keep \n, \t, \r)
                content = content.replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]", "");
                // JSON-encode for safe JS string passing
                String jsonContent;
                try {
                    jsonContent = new org.json.JSONObject().put("content", content).toString();
                } catch (Throwable je) {
                    Log.e(TAG, "JSON encoding failed for stats PGN content", je);
                    jsonContent = "{\"content\":\"\"}";
                }
                evalJs("if(typeof onStatsPGNFileRead==='function'){try{var _d=" + jsonContent + ";onStatsPGNFileRead(_d.content);}catch(e){console.error('stats PGN read callback error:',e);}}");
            } catch (Throwable e) {
                Log.e(TAG, "Stats PGN file read failed", e);
                evalJs("if(typeof onStatsPGNFileRead==='function')onStatsPGNFileRead('')");
            }
        }
    }

    private void evalJs(final String js) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // v1.2.3 round-48 (BUG-2): logic extracted to handleBackKeyPress()
        //   (shared with the API 33+ OnBackInvokedCallback — on API 33+ this
        //   onKeyDown branch no longer receives KEYCODE_BACK at all).
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (handleBackKeyPress()) {
                return true;
            }
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // v1.2.1 round-10 (review-E P2): Add onPause/onResume to pause/resume the
    //   WebView's JS timers when the user backgrounds the activity. Previously
    //   the stats page's setInterval-based animations and any in-flight
    //   evaluateJavascript callbacks kept running in the background, draining
    //   battery and (on HyperOS 3) raising the app's background-CPU score,
    //   which could trigger more aggressive process freezing. MainActivity
    //   has had this pair since v1.0.8; StatsActivity now matches.
    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            try { webView.onPause(); } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            try { webView.onResume(); } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onDestroy() {
        // v1.2.3 round-48 (BUG-2): unregister the API 33+ back callback so the
        //   dispatcher cannot invoke a destroyed Activity.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU && _backInvokedCallback != null) {
            try {
                getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(_backInvokedCallback);
            } catch (Throwable e) {
                Log.w(TAG, "OnBackInvokedCallback unregister failed", e);
            }
            _backInvokedCallback = null;
        }
        // v1.0.8 PHASE 30: Full 6-step WebView teardown (matching MainActivity).
        //   Previously only webView.destroy() was called, which could leak JS
        //   callbacks, cause WindowLeaked exceptions, and leave a stale
        //   AndroidBridge interface pointing to the destroyed StatsActivity.
        if (webView != null) {
            // v1.2.1: 与 MainActivity.onDestroy 保持一致 —— 先 stopLoading() 终止
            //   in-flight 加载，避免某些 OEM ROM（HyperOS 3 / MIUI）在 destroy()
            //   后仍派发 load 回调到已销毁的 native peer，触发 SIGSEGV。
            try { webView.stopLoading(); } catch (Throwable ignored) {}
            try {
                if (webView.getParent() instanceof android.view.ViewGroup) {
                    ((android.view.ViewGroup) webView.getParent()).removeView(webView);
                }
            } catch (Throwable ignored) {}
            try { webView.clearHistory(); } catch (Throwable ignored) {}
            try { webView.loadUrl("about:blank"); } catch (Throwable ignored) {}
            try { webView.removeJavascriptInterface("AndroidBridge"); } catch (Throwable ignored) {}
            try { webView.onPause(); } catch (Throwable ignored) {}
            try { webView.destroy(); } catch (Throwable ignored) {}
            webView = null;
        }
        // v1.2.3 round-44 (E4): 清掉未触发的 BACK 兜底 Runnable，避免持有
        //   Activity 引用到超时。
        if (backFallbackHandler != null) {
            backFallbackHandler.removeCallbacksAndMessages(null);
        }
        super.onDestroy();
    }
}
