package com.Regalia;

/*
 * Regalia - JS Bridge Gateway
 * Copyright (C) 2026 Regalia
 *
 * Engine management logic derived from DroidFish
 * Copyright (C) Peter Österlund (original DroidFish logic)
 * Modifications Copyright (C) 2026 Regalia
 *
 * AI-GEN: AI assisted + DroidFish source code logic reference
 * This code was AI-assisted and has been reviewed for GPL v3 compliance.
 *
 * v1.2.0: Extracted from StockfishNative.java (Phase 73 God Module split).
 *         Provides sandbox-safe path validation and UCI command whitelisting
 *         for all JavaScript → Java bridge calls.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * JsBridgeGateway — JS 桥接网关 (v1.2.0 Phase 73)
 *
 * 职责:
 *   - 沙箱路径验证（防止目录穿越攻击）
 *   - UCI 命令白名单过滤（防止恶意命令注入）
 *   - 输入参数校验
 *   - 资源访问权限检查
 *
 * 安全设计:
 *   - 所有文件操作必须先通过 isPathInSandbox() 验证
 *   - 所有 sendToEngine() 调用必须通过 isUciCommandAllowed() 白名单检查
 *   - 路径规范化使用 getCanonicalFile() 防止符号链接绕过
 */
public class JsBridgeGateway {
    private static final String TAG = "JsBridgeGateway";

    private final Context context;

    /** UCI 命令白名单前缀（防止恶意命令注入） */
    private static final Set<String> UCI_COMMAND_WHITELIST = new HashSet<>();
    static {
        UCI_COMMAND_WHITELIST.add("uci");
        UCI_COMMAND_WHITELIST.add("isready");
        UCI_COMMAND_WHITELIST.add("setoption");
        UCI_COMMAND_WHITELIST.add("ucinewgame");
        UCI_COMMAND_WHITELIST.add("position");
        UCI_COMMAND_WHITELIST.add("go");
        UCI_COMMAND_WHITELIST.add("stop");
        UCI_COMMAND_WHITELIST.add("ponderhit");
        UCI_COMMAND_WHITELIST.add("quit");
        UCI_COMMAND_WHITELIST.add("d");
        UCI_COMMAND_WHITELIST.add("flip");
        UCI_COMMAND_WHITELIST.add("compiler");
        UCI_COMMAND_WHITELIST.add("eval");
        UCI_COMMAND_WHITELIST.add("perft");
        UCI_COMMAND_WHITELIST.add("bench");
        UCI_COMMAND_WHITELIST.add("stockfish");
    }

    public JsBridgeGateway(Context context) {
        this.context = context.getApplicationContext();
    }

    /**
     * 验证路径是否在应用沙箱内（filesDir 或 cacheDir）。
     * 使用 getCanonicalFile() 解析符号链接，防止目录穿越攻击。
     *
     * @param path 待验证的路径
     * @return true 表示路径安全（在沙箱内）
     */
    public boolean isPathInSandbox(String path) {
        if (path == null || path.isEmpty()) return false;
        try {
            File target = new File(path).getCanonicalFile();
            File filesDir = context.getFilesDir().getCanonicalFile();
            File cacheDir = context.getCacheDir().getCanonicalFile();
            String targetPath = target.getPath();
            String filesPath = filesDir.getPath();
            String cachePath = cacheDir.getPath();
            // v1.2.1: 必须追加 File.separator 才允许 startsWith —— 否则
            //   /data/data/com.Regalia/files_evil/x 会通过 filesDir 检查
            //   （"files_evil".startsWith("files") == true），构成沙箱穿越。
            //   允许 equals(targetPath) 是因为 filesDir / cacheDir 自身合法。
            boolean underFiles = targetPath.equals(filesPath)
                    || targetPath.startsWith(filesPath + File.separator);
            boolean underCache = targetPath.equals(cachePath)
                    || targetPath.startsWith(cachePath + File.separator);
            return underFiles || underCache;
        } catch (IOException e) {
            Log.w(TAG, "Path canonicalization failed: " + path, e);
            return false;
        } catch (SecurityException e) {
            Log.w(TAG, "Security manager denied access: " + path, e);
            return false;
        }
    }

    /**
     * v1.2.3 round-54 (PR56 CR#12): browsing gate for READ-ONLY directory
     *   navigation (listFiles / getParentPath). getDefaultPaths() surfaces
     *   app-specific external files, Downloads and Documents as the JS file
     *   browser's roots — on API 29+ those roots live OUTSIDE the strict
     *   isPathInSandbox() dirs, so the browser previously opened to a
     *   guaranteed-"[]" listing (the round-49 review-4 P3-6 sandbox gate is
     *   correct for reads/writes but made the built-in browser useless on
     *   modern Android). Widening the shared sandbox was rejected (it would
     *   re-open arbitrary-path enumeration); instead this separate gate
     *   whitelists exactly the browsable roots, canonicalized per call.
     *   Read/write/delete operations must keep using isPathInSandbox() — the
     *   settings import flow routes through SafPickerHelper (SAF) for files
     *   outside the sandbox.
     */
    public boolean isPathBrowsable(String path) {
        if (isPathInSandbox(path)) return true;
        if (path == null || path.isEmpty()) return false;
        try {
            String targetPath = new File(path).getCanonicalFile().getPath();
            java.util.List<File> roots = new java.util.ArrayList<>();
            File extFiles = context.getExternalFilesDir(null);
            if (extFiles != null) roots.add(extFiles);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                File base = android.os.Environment.getExternalStorageDirectory();
                roots.add(new File(base, "Download"));
                roots.add(new File(base, "Documents"));
            } else {
                roots.add(android.os.Environment.getExternalStoragePublicDirectory(
                        android.os.Environment.DIRECTORY_DOWNLOADS));
                roots.add(android.os.Environment.getExternalStoragePublicDirectory(
                        android.os.Environment.DIRECTORY_DOCUMENTS));
            }
            for (File root : roots) {
                String rootPath = root.getCanonicalFile().getPath();
                if (targetPath.equals(rootPath)
                        || targetPath.startsWith(rootPath + File.separator)) {
                    return true;
                }
            }
            return false;
        } catch (IOException e) {
            Log.w(TAG, "Browsable-path canonicalization failed: " + path, e);
            return false;
        } catch (SecurityException e) {
            Log.w(TAG, "Security manager denied access: " + path, e);
            return false;
        }
    }

    /**
     * 验证 UCI 命令是否在白名单内。
     * 提取命令的第一个 token，检查是否在白名单中。
     *
     * @param command 待验证的 UCI 命令
     * @return true 表示命令允许
     */
    public boolean isUciCommandAllowed(String command) {
        if (command == null || command.trim().isEmpty()) return false;
        // v1.2.3 round-13 (P0): UCI commands are single-line by spec. Reject
        //   embedded CR/LF to prevent command injection — a whitelisted prefix
        //   must not smuggle extra lines (e.g. "setoption name X value 1\nquit"
        //   would otherwise kill the engine). sendSetOptionAndWait already
        //   strips newlines via stripNewlines(), but sendToEngine (which calls
        //   sendUciCommand directly) does not, so the whitelist is the only
        //   gate for that path.
        if (command.indexOf('\n') >= 0 || command.indexOf('\r') >= 0) {
            // v1.2.3 round-19 (gitar-bot / SonarCloud java:S5443): sanitize
            //   CR/LF BEFORE logging. trim() only strips leading/trailing
            //   whitespace, so an embedded '\n'/'\r' would still reach
            //   logcat and allow forged log lines. String.replace is literal
            //   (no regex), turning each CR/LF into a visible escape so the
            //   blocked payload stays on a single log line.
            Log.w(TAG, "Blocked UCI command with embedded newline: "
                    + command.trim().replace("\r", "\\r").replace("\n", "\\n"));
            return false;
        }
        String trimmed = command.trim();
        // 提取第一个 token（命令名）
        int spaceIdx = trimmed.indexOf(' ');
        String cmdName = spaceIdx > 0 ? trimmed.substring(0, spaceIdx) : trimmed;
        cmdName = cmdName.toLowerCase();
        boolean allowed = UCI_COMMAND_WHITELIST.contains(cmdName);
        if (!allowed) {
            Log.w(TAG, "Blocked non-whitelisted UCI command: " + cmdName);
        }
        return allowed;
    }

    /**
     * 验证文件名是否安全（不含路径分隔符、控制字符）。
     * 用于 savePGNCache / setPGNCacheTags 等接受文件名的接口。
     *
     * @param name 待验证的文件名
     * @return true 表示文件名安全
     */
    public boolean isSafeFileName(String name) {
        if (name == null || name.isEmpty()) return false;
        // 禁止路径分隔符
        if (name.contains("/") || name.contains("\\")) return false;
        // 禁止 .. 目录穿越
        if (name.contains("..")) return false;
        // 禁止控制字符
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c < 0x20 || c == 0x7F) return false;
        }
        // 限制长度
        return name.length() <= 200;
    }

    /**
     * 验证 URL 是否使用允许的协议（http/https/mailto）。
     * 用于 openUrlInBrowser 接口。
     *
     * @param url 待验证的 URL
     * @return true 表示 URL 安全
     */
    public boolean isUrlSafe(String url) {
        if (url == null || url.isEmpty()) return false;
        String lower = url.toLowerCase();
        return lower.startsWith("http://")
                || lower.startsWith("https://")
                || lower.startsWith("mailto:");
    }

    /**
     * 验证 FEN 字符串格式是否合法。
     * 简单检查：6 段空格分隔，非空。
     *
     * @param fen 待验证的 FEN
     * @return true 表示格式基本合法
     */
    public boolean isValidFen(String fen) {
        if (fen == null || fen.trim().isEmpty()) return false;
        String[] parts = fen.trim().split("\\s+");
        // 标准 FEN 有 6 段，Chess960 FEN 也可能有 6 段
        return parts.length >= 4 && parts.length <= 6;
    }

    /**
     * 验证 JSON 字符串是否合法。
     *
     * @param json 待验证的 JSON
     * @return true 表示 JSON 合法
     */
    public boolean isValidJson(String json) {
        if (json == null || json.trim().isEmpty()) return false;
        try {
            new org.json.JSONObject(json);
            return true;
        } catch (Throwable notObj) {
            try {
                new org.json.JSONArray(json);
                return true;
            } catch (Throwable notArr) {
                return false;
            }
        }
    }

    /** 获取沙箱根目录（filesDir） */
    public File getSandboxRoot() {
        return context.getFilesDir();
    }

    /** 获取缓存目录 */
    public File getCacheRoot() {
        return context.getCacheDir();
    }
}
